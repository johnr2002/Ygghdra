
# YGDHRA CHARACTER CREATION SYSTEM

## CREATION FLOW SEQUENCE

### 1. Game Mode Selection
**MANDATORY FIRST STEP:**
```
Welcome to YGDHRA: Dublin 2025
Choose your game mode:
1. Single Player
2. Co-operative (2 Players)

[WAIT FOR INPUT - DO NOT CONTINUE]
```

### 2. Character Creation Introduction
"You are about to create your survivor for the Dublin zombie apocalypse. This character will be your avatar in a harsh world where every choice matters and death is permanent. Take time to consider each choice carefully."

### 3. Basic Information
**Name:** "What is your character's name?"
**Age:** "How old is your character? (16-65)"
**Gender:** "Character's gender?" (Optional - for roleplay flavor)

### 4. Physical Description
**Appearance:** "Briefly describe your character's appearance (height, build, notable features):"
- Keep to 1-2 sentences
- Affects some social interactions
- No mechanical impact but adds immersion

### 5. Background/Profession Selection
**Choose your pre-apocalypse profession:**

**MEDICAL PROFESSIONALS**
- **Doctor:** Medical +3, Intelligence +1, starts with medical kit
- **Nurse:** Medical +2, Social +1, starts with first aid supplies  
- **Paramedic:** Medical +2, Athletics +1, starts with trauma kit
- **Veterinarian:** Medical +2, Survival +1, starts with surgical tools

**LAW ENFORCEMENT/MILITARY**
- **Police Officer:** Firearms +2, Social +1, starts with service pistol (15 rounds)
- **Security Guard:** Combat (Melee) +2, Perception +1, starts with baton, radio
- **Military (Active):** Firearms +3, Athletics +1, starts with tactical gear
- **Military (Veteran):** Combat +2, Survival +1, starts with survival knife

**SKILLED TRADES**
- **Mechanic:** Mechanical +3, Strength +1, starts with tool kit
- **Electrician:** Mechanical +2, Intelligence +1, starts with electrical tools
- **Carpenter:** Mechanical +2, Strength +1, starts with hand tools
- **Engineer:** Mechanical +2, Intelligence +2, starts with technical manuals

**SERVICE/SOCIAL**
- **Teacher:** Social +2, Intelligence +1, starts with first aid knowledge
- **Bartender:** Social +3, Perception +1, starts with local knowledge
- **Social Worker:** Social +2, Medical +1, starts with community contacts
- **Priest/Clergy:** Social +3, starts with community trust

**PHYSICAL LABOR**
- **Construction Worker:** Strength +2, Athletics +1, starts with hard hat, tools
- **Farmer:** Survival +2, Strength +1, starts with farming knowledge
- **Delivery Driver:** Athletics +1, Survival +1, starts with Dublin map knowledge
- **Warehouse Worker:** Strength +2, Athletics +1, starts with lifting experience

**STUDENT/UNEMPLOYED**
- **University Student:** Intelligence +1, choose any +1 skill, starts with backpack
- **Unemployed:** Choose any two +1 skills, starts with street knowledge

### 6. Personality/Trauma Response
**How does your character handle violence and trauma?**

**A) Empathetic:** 
- Deeply affected by violence and death
- -1 to actions after witnessing/causing death (1 hour)
- +2 to social interactions with other survivors
- Loyalty gains +25% faster with companions

**B) Stoic:**
- Emotionally controlled, suppresses feelings
- No immediate penalties from violence
- -1 to social interactions (seems cold)
- Stress accumulates, occasional -2 penalty (1 day) when overwhelmed

**C) Hardened:**
- Little emotional response to violence
- No penalties from causing death
- -2 to social interactions with empathetic NPCs
- +1 to intimidation attempts

**D) Adaptive:**
- Adjusts response based on situation
- Minor -1 penalty first few times, then adapts
- Balanced social interactions
- Can shift between approaches as needed

### 7. Attribute Distribution
**Base Attributes (all start at 2, distribute 6 points, max 5 during creation):**

- **Strength:** Melee damage, carrying capacity, physical labor
- **Endurance:** Health points (END x 3), stamina, disease resistance  
- **Agility:** Speed, stealth, dodge chance, fine motor skills
- **Intelligence:** Learning speed, crafting, medicine, technology
- **Perception:** Awareness, ranged accuracy, finding hidden items
- **Charisma:** Social interactions, leadership, animal handling

**Health Points:** Endurance x 3 + 5
**Stamina:** Endurance x 2 + Strength + 10

### 8. Skill Point Distribution
**Distribute 5 additional skill points among:**
- Combat (Melee) - Hand weapons, unarmed fighting
- Combat (Firearms) - Guns, bows, accuracy
- Medical - First aid, surgery, infection treatment
- Mechanical - Repair, crafting, electronics  
- Stealth - Sneaking, hiding, silent movement
- Athletics - Running, climbing, swimming
- Survival - Foraging, navigation, weather prediction
- Social - Persuasion, leadership, reading people

### 9. Optional Traits (Choose up to 2)
**POSITIVE TRAITS:**
- **Alert:** +2 to perception rolls, harder to surprise
- **Brave:** +2 to resist fear effects, +1 vs intimidation
- **Quick Learner:** Skills improve 25% faster
- **Lucky:** Reroll one failed roll per day
- **Strong Back:** +50% carrying capacity
- **Night Vision:** Reduced darkness penalties
- **Medically Trained:** +1 to all medical actions
- **Mechanical Aptitude:** +1 to all repair/crafting

**NEGATIVE TRAITS (grant +1 extra skill point each):**
- **Asthmatic:** -1 to stamina, -2 when running/fighting hard
- **Bad Hearing:** -2 to audio-based perception
- **Slow Healer:** Wounds take 50% longer to heal
- **Unlucky:** One automatic failure per day (AI decides when)
- **Weak Stomach:** -2 to actions after seeing gore
- **Claustrophobic:** -2 to actions in enclosed spaces
- **Insomniac:** Need 25% more rest to recover

### 10. Starting Equipment
**Base Equipment (everyone gets):**
- Casual clothing appropriate to background
- Basic personal items (wallet, keys, phone - though mostly useless)
- €50-200 cash (varies by background)

**Professional Equipment (based on background choice):**
*Already specified in background descriptions*

**Starting Location Choice:**
- **Your Apartment:** Safe, known area, some supplies
- **Workplace:** Professional equipment, might know colleagues
- **Public Location:** Random encounter, less predictable

### 11. Character Sheet Confirmation
```
═══ CHARACTER CONFIRMATION ═══
Name: [Character Name]
Age: [X] | Background: [Profession]
Personality: [Trauma Response Type]

ATTRIBUTES:
Strength: [X] | Endurance: [X] | Agility: [X]
Intelligence: [X] | Perception: [X] | Charisma: [X]

DERIVED STATS:
Health: [X/X] | Stamina: [X/X]

SKILLS:
[List all skills with bonuses]

TRAITS:
[List chosen traits and effects]

STARTING EQUIPMENT:
[List all starting gear]

Starting Location: [Chosen location]

Confirm this character? (Y/N)
═══════════════════════════════
```

### 12. Co-op Coordination (if Co-op mode)
**After both characters created:**
"How do you know each other?"
- Work colleagues
- Friends/family
- Neighbors  
- Strangers who meet during crisis
- Military/police partners

**Starting Situation:**
"Where are you when the crisis begins?"
- Together at work
- Meeting for social reasons
- Randomly encounter each other
- Sheltering in same location

## CHARACTER CREATION RULES

### Mechanical Balance
- No attribute above 5 during creation
- Skill bonuses from background + distribution cannot exceed +5
- Positive traits must be balanced by consequences
- Starting equipment appropriate to background only

### Realism Constraints
- Ages 16-65 for different physical capabilities
- Backgrounds must match logical skill distributions
- No combat-focused civilians without military/police background
- Equipment must make sense for 2025 Dublin setting

### Co-op Considerations
- Characters should complement each other
- Avoid duplicate specializations unless planned
- Consider how backstories connect
- Starting relationship affects initial trust

### Character Advancement Preview
"Your character will improve through:"
- **Experience:** Successful skill use increases skill levels
- **Training:** NPCs can teach new techniques
- **Equipment:** Better gear found or crafted over time
- **Survival:** Each day survived builds mental resilience

### Important Reminders
- **Death is permanent** - no resurrection mechanics
- **Choices have lasting consequences** - NPCs remember everything
- **Infection can be fatal** - medical knowledge is crucial
- **Resources are scarce** - plan carefully
- **Trust is earned** - relationships develop over time

## STARTING NARRATIVE TRANSITION

After character creation confirmed:
"Your character is ready. The date is **November 15th, 2025 - Day -2**. Strange reports are emerging on Dublin news stations about a 'flu outbreak' with unusual symptoms. Most people are going about their normal routines, but there's an undercurrent of unease in the city. 

You don't know it yet, but you have 48 hours before everything changes forever..."

**[PROCEED TO GAME START - Day -2 Morning]**
