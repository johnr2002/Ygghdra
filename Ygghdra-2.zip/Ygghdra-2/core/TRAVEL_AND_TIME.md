
# YGDHRA TRAVEL AND TIME SYSTEM

## TRAVEL MECHANICS

### Movement Speeds
**On Foot:**
- **Walking:** 3 mph, quiet, low stamina drain
- **Jogging:** 5 mph, moderate noise, medium stamina drain  
- **Running:** 8 mph, loud, high stamina drain, limited duration
- **Sneaking:** 1 mph, very quiet, low stamina drain

**With Transportation:**
- **Bicycle:** 10 mph, quiet, medium stamina drain, weather dependent
- **Motorcycle:** 25 mph, very loud, attracts attention from miles
- **Car:** 20 mph (city), loud, fuel consumption, road conditions matter
- **Heavy Vehicle:** 15 mph, extremely loud, high fuel consumption

### Distance Calculations - Dublin Geography
**Inner City Distances:**
- **Temple Bar to Trinity College:** 0.5 miles (10 min walk)
- **City Center to Phoenix Park:** 2 miles (40 min walk)  
- **Grafton Street to Docklands:** 1.5 miles (30 min walk)
- **North Side to South Side:** 1 mile (20 min walk via bridges)

**Cross-City Travel:**
- **Dublin City to Suburbs:** 3-8 miles (1-3 hours on foot)
- **Major District Traversal:** 2-4 miles (45-90 min on foot)
- **Safe Route Detours:** Add 50-100% to travel time

### MANDATORY TRAVEL CHOICE FORMAT

**Every travel option MUST include:**
```
[Destination] - ([ETA], [Risk Level])

Examples:
1. Trinity College Library - (25 minutes, LOW RISK)
2. Grafton Street Shopping District - (45 minutes, HIGH RISK) 
3. Phoenix Park Militia Base - (2 hours, MODERATE RISK)
4. Dublin Port Docklands - (1.5 hours, EXTREME RISK)
```

### Risk Assessment Categories

**LOW RISK:**
- Recently cleared areas
- Daylight travel on known safe routes
- Short distances through familiar territory
- Areas with active survivor presence

**MODERATE RISK:**
- Standard city travel during day
- Areas not recently scouted
- Medium distances through mixed terrain
- Some zombie activity reported

**HIGH RISK:**
- Dense urban areas with limited escape routes
- Night travel or poor weather conditions
- Areas with confirmed zombie concentrations
- Hostile survivor territory

**EXTREME RISK:**
- Known zombie horde locations
- Completely unscouted dangerous areas
- Travel during storms or extreme conditions
- Active combat zones or faction conflicts

## TIME PROGRESSION SYSTEM

### Time Tracking
**Current Time Display:**
```
Day [X] - [Morning/Afternoon/Evening/Night] ([HH:MM])
Weather: [Current conditions]
```

**Day Cycle Phases:**
- **Morning:** 06:00-12:00 (Good visibility, moderate activity)
- **Afternoon:** 12:00-18:00 (Best visibility, high activity)  
- **Evening:** 18:00-22:00 (Declining visibility, moderate activity)
- **Night:** 22:00-06:00 (Poor visibility, low activity, zombies more active)

### Time Advancement Rules
**Action-Based Time:**
- **Simple Actions:** 1-5 minutes (searching a room, basic conversation)
- **Complex Actions:** 10-30 minutes (detailed search, crafting, first aid)
- **Major Activities:** 1-4 hours (travel, base building, extensive medical care)
- **Rest Periods:** 6-8 hours (full sleep, extended recovery)

**Automatic Advancement:**
- **Event-Driven:** Time advances as needed for narrative pacing
- **Travel Time:** Calculated based on distance and method
- **Activity Duration:** Realistic time for tasks to complete
- **Rest Cycles:** Characters need regular sleep and meals

### Day/Night Cycle Effects

**Daytime Advantages:**
- +2 to perception rolls (good visibility)
- Easier navigation and pathfinding
- NPCs more likely to be active and responsive
- Solar-powered equipment functions

**Daytime Disadvantages:**
- Higher zombie activity in some areas
- More visible to hostile survivors
- Hotter temperatures may drain stamina faster

**Nighttime Advantages:**
- +2 to stealth rolls (harder to see)
- Some zombie types less active
- Cooler temperatures
- NPCs may let guard down

**Nighttime Disadvantages:**
- -3 to perception rolls (poor visibility)
- Navigation much more difficult
- Some zombie types become more aggressive
- Cold temperatures drain stamina
- Electronic devices more visible (flashlights)

## ENCOUNTER SYSTEM

### Travel Encounter Frequency
**Per Hour of Travel - Roll vs TN:**
- **Safe Areas:** TN 18 (encounters very rare)
- **Low Risk Areas:** TN 15 (occasional encounters)
- **Moderate Risk Areas:** TN 12 (regular encounters)
- **High Risk Areas:** TN 9 (frequent encounters)
- **Extreme Risk Areas:** TN 6 (constant danger)

### Encounter Types
**Zombie Encounters (60% of encounters):**
- Single wandering zombie
- Small group (2-3 zombies)
- Feeding zombies (distracted, can avoid)
- Horde blocking path (must detour or wait)

**Human Encounters (25% of encounters):**
- Lone survivor seeking help
- Hostile scavenger group
- Faction patrol (friendly/neutral/hostile)
- Trader with goods to barter

**Environmental Encounters (15% of encounters):**
- Blocked or damaged roads
- Useful resource cache
- Abandoned vehicle (may have supplies/fuel)
- Weather change affecting travel

### Encounter Resolution
**Detection Phase:**
- Perception roll to notice encounter first
- High perception = better options (avoid, ambush, etc.)
- Low perception = encounter happens without warning

**Response Options:**
- **Engage:** Enter combat or social interaction
- **Avoid:** Attempt to bypass encounter (Stealth roll)
- **Retreat:** Turn back and find alternate route
- **Observe:** Watch and gather information before acting

## WEATHER SYSTEM - Dublin Climate

### Weather Patterns
**Common Weather (60%):**
- Light rain or drizzle (very common in Dublin)
- Overcast with occasional breaks
- Cool temperatures (10-15°C typical)
- Light winds

**Challenging Weather (30%):**
- Heavy rain with poor visibility
- Strong winds affecting movement
- Cold temperatures (below 5°C)
- Dense fog reducing vision severely

**Severe Weather (10%):**
- Storm conditions with dangerous winds
- Flooding in low-lying areas
- Extreme cold (below 0°C)
- Combination of multiple weather factors

### Weather Effects on Travel

**Light Rain:**
- -1 to perception rolls
- +1 to stealth (sound masking)
- Infection treatment -1 effectiveness if performed outdoors

**Heavy Rain:**
- -2 to perception rolls
- +2 to stealth (sound masking)  
- Movement speed reduced by 25%
- Risk of hypothermia if inadequately clothed
- Electronics may malfunction if not protected

**Fog:**
- -3 to perception rolls beyond 20 feet
- +3 to stealth rolls
- Easy to get lost (Navigation roll required)
- Zombies may not notice you until very close

**Storm Conditions:**
- Travel becomes dangerous (TN 15 to avoid injury)
- Visibility severely reduced (-5 perception)
- High chance of getting lost
- Risk of falling debris or flooding
- Electronic devices unreliable

**Cold Weather:**
- -1 to all actions without proper clothing
- Stamina drains 25% faster
- Medical treatment less effective
- Vehicle batteries may fail

## NAVIGATION AND GETTING LOST

### Navigation Requirements
**Familiar Areas:** No roll needed for known routes
**New Areas with Map/Guide:** TN 8 Navigation roll
**New Areas, No Map:** TN 12 Navigation roll  
**Poor Conditions:** +3 to +5 TN modifier
**Landmarks Destroyed:** +2 to TN modifier

### Getting Lost Consequences
- **Minor Deviation:** Add 25% to travel time
- **Significant Detour:** Add 50% to travel time, extra encounter roll
- **Completely Lost:** Double travel time, multiple encounter rolls
- **Dangerous Area:** May end up in high-risk zone unintentionally

### Navigation Aids
**Physical Maps:** +2 to navigation rolls (if current)
**Local Guide NPC:** +3 to navigation rolls
**Smartphone GPS:** +4 (if working and has power)
**Landmarks:** +1 to +2 depending on visibility
**Road Signs:** +1 (if not damaged/removed)

## STAMINA AND EXHAUSTION

### Stamina Costs
**Light Activity:** -1 stamina per hour (walking, light work)
**Moderate Activity:** -2 stamina per hour (jogging, manual labor)
**Heavy Activity:** -5 stamina per hour (running, combat, heavy lifting)
**Extreme Activity:** -10 stamina per hour (sprinting, intense combat)

### Exhaustion Stages
**Tired (50% stamina):** -1 to all actions
**Exhausted (25% stamina):** -2 to all actions, movement speed halved
**Dead on Feet (10% stamina):** -3 to all actions, risk of collapse
**Collapse (0% stamina):** Character falls unconscious

### Rest and Recovery
**Light Rest:** +2 stamina per hour (sitting, light conversation)
**Moderate Rest:** +4 stamina per hour (lying down, safe environment)
**Deep Sleep:** +6 stamina per hour (secure location, proper bedding)
**Medical Rest:** +8 stamina per hour (medical care, proper nutrition)

## VEHICLE SYSTEM

### Vehicle Availability
**Abandoned Cars:** Many available but may lack fuel/keys
**Motorcycles:** Faster but more exposed to danger
**Bicycles:** Quiet, no fuel needed, limited carrying capacity
**Heavy Vehicles:** Trucks, vans - high fuel consumption but more storage

### Vehicle Conditions
**Excellent:** No mechanical issues, full tank
**Good:** Minor wear, 75% fuel
**Fair:** Some problems, 50% fuel, may break down
**Poor:** Frequent breakdowns, 25% fuel
**Broken:** Non-functional, needs major repairs

### Fuel Scarcity
- **Fuel consumption tracked realistically**
- **Gas stations mostly empty or dangerous**
- **Siphoning fuel from other vehicles**
- **Generator/vehicle competition for fuel resources**

### Vehicle Noise and Attention
**Motorcycle:** Attracts attention from 2-3 miles away
**Car:** Attracts attention from 1-2 miles away
**Heavy Vehicle:** Attracts attention from 3-5 miles away
**Bicycle:** Minimal noise, only close detection

## TIME PRESSURE MECHANICS

### Urgent Situations
**Medical Emergencies:** Infection treatment windows create time pressure
**Rescue Missions:** NPCs in danger have limited time before death
**Resource Depletion:** Food/water running out forces action
**Faction Deadlines:** Political situations with time limits

### Anti-Camping Measures
**Safe Area Degradation:** Even "safe" areas become dangerous over time
**Resource Depletion:** Staying in one place too long exhausts local resources
**Faction Movement:** Political situations evolve, safe areas change hands
**Zombie Migration:** Horde movements force evacuation

### World Evolution Over Time
**Week 1:** Initial chaos, military still responding, some services functioning
**Week 2-4:** Military collapse, faction formation, resource competition
**Month 2-3:** Established territories, trade networks, political stability
**Month 4+:** Long-term survival communities, zombie adaptation, seasonal challenges

This travel and time system creates realistic constraints while maintaining narrative pacing and ensuring that every journey involves meaningful risk/reward decisions.
