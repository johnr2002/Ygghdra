
# YGDHRA INFECTION SYSTEM

## DUAL-SCALE INFECTION TRACKING

### Hidden Corruption Points (CP) - Internal Scale 0-15
- **Internal tracking only** - AI uses this for calculations
- **CP 15 = 100% infection = permanent death/turning**
- **Each CP ≈ 6.67% on player-visible meter**

### Player-Visible Infection Meter (0-100%)
- **Displayed in stat window** when above 0%
- **Rounds to nearest 5%** for simplicity
- **Key thresholds at 25%, 50%, 75%, 90%**

## INFECTION SOURCES AND CP GAIN

### Direct Zombie Contact
- **Zombie Scratch:** +2 to +3 CP (minor exposure)
- **Zombie Bite:** +4 to +6 CP (major exposure, depends on depth)
- **Multiple Bites:** Each additional bite +3 to +4 CP
- **Zombie Blood Contact:** +1 to +3 CP (eyes, open wounds, mouth)

### Environmental Exposure
- **Contaminated Food/Water:** +1 to +2 CP
- **Toxic Zones (sewers, hospitals):** +1 to +4 CP per hour exposure
- **Contaminated Medical Equipment:** +1 to +2 CP if used improperly
- **Dead Body Fluids:** +1 CP (handling without protection)

### Amplifying Conditions
- **Cold/Wet Environment:** +25% CP gain from any source
- **High Stress/Exhaustion:** +1 CP on critical failures
- **Poor Nutrition:** +1 CP modifier when already infected
- **Existing Wounds:** Open wounds double infection risk

### Ongoing Infection
- **Untreated Deep Wounds:** +1 CP per 4 hours until properly cleaned
- **Poor Hygiene:** +1 CP per day in unsanitary conditions (50%+ infection)
- **Overexertion:** +1 CP if strenuous activity while 75%+ infected

## INFECTION STAGE EFFECTS

### 0% - Healthy (0 CP)
- No symptoms or penalties
- Normal function in all areas
- Hidden from stat window

### 1-25% - Early Infection (1-3 CP)
- **Symptoms:** Slight fatigue, occasional headache
- **Mechanical Effects:** No penalties yet
- **Social:** Symptoms not obvious to others
- **Contagious:** Not yet contagious to others

### 26-50% - Deteriorating (4-7 CP)
- **Symptoms:** Low-grade fever, sweating, nausea
- **Mechanical Effects:** -1 to all actions
- **Social:** Others notice you seem unwell
- **Contagious:** Not yet contagious

### 51-75% - Critical Stage (8-11 CP)
- **Symptoms:** High fever, delirium, severe weakness
- **Mechanical Effects:** -2 to all actions
- **Special:** Stamina maximum reduced by 25%
- **Social:** NPCs become concerned, may keep distance
- **Contagious:** Blood and saliva can infect others (+1 CP risk)
- **Hallucinations:** AI may present false sensory information

### 76-90% - Terminal Stage (12-14 CP)
- **Symptoms:** Convulsions, bleeding, organ failure
- **Mechanical Effects:** -3 to all actions
- **Special:** Stamina maximum reduced by 50%
- **Social:** NPCs treat as dangerous, may refuse contact
- **Contagious:** Highly contagious through any fluid contact
- **Mental Effects:** Frequent hallucinations, paranoia

### 91-99% - Final Stage (15 CP approaching)
- **Symptoms:** Near-death state, consciousness fading
- **Mechanical Effects:** -4 to all actions
- **Special:** Cannot exert (no combat/running), stamina maximum 5
- **Social:** NPCs may attack or flee on sight
- **Time Limit:** Will turn within 24 hours without treatment

### 100% - Turned (15 CP)
- **PERMANENT DEATH - CHARACTER IS LOST**
- **No resurrection mechanics**
- **Character becomes zombie NPC**
- **Co-op partner must deal with turned character**

## TREATMENT SYSTEM - FOUR TIME WINDOWS

### 1. Immediate Field Treatment (0-2 Minutes)
**Actions Available:**
- Apply pressure to bleeding wound
- Rinse with clean water/alcohol if available
- Tourniquet for limb bites (extreme measure)
- Basic wound cleaning with available materials

**Requirements:**
- Any clean cloth or bandage material
- Water/alcohol preferred but not required
- Medical skill helps but not required

**Results:**
- **Success (TN 8):** -1 CP, stops ongoing bleed
- **Failure:** No change, wound continues to deteriorate
- **Critical Success:** -2 CP, wound stabilized

**Modifiers:**
- Clean environment: +2
- Medical supplies: +2
- Medical skill: +1 per skill level
- Dirty environment: -2
- Under pressure/combat: -3

### 2. Early First Aid (2 minutes - 1 hour)
**Actions Available:**
- Thorough wound cleaning and disinfection
- Proper bandaging and wound closure
- Pain medication administration
- Antiseptic application

**Requirements:**
- First aid kit or improvised medical supplies
- Clean working area preferred
- Medical skill check required

**Results:**
- **Success (TN 10):** -1 to -2 CP, prevents ongoing infection
- **Failure:** No change or +1 CP if badly botched
- **Critical Success:** -3 CP, wound properly treated

**Modifiers:**
- Professional first aid kit: +3
- Improvised supplies: -1
- Clean indoor area: +2
- Outdoors/dirty: -2
- Medical skill: +1 per skill level
- Assistant helping: +1

### 3. Golden Hour Medical Care (1-6 hours)
**Actions Available:**
- Antibiotic administration (IV or oral)
- Advanced wound cleaning and suturing
- IV fluid therapy for shock
- Professional medical assessment

**Requirements:**
- Antibiotics (rare and valuable)
- Medical facility or clean area
- Medical skill 3+ or qualified NPC
- Advanced medical supplies

**Results:**
- **Success (TN 12):** -2 to -4 CP depending on quality
- **Failure:** -1 CP or no change
- **Critical Failure:** +1 CP from contamination

**Modifiers:**
- Hospital setting: +4
- Clinic/clean facility: +2
- Field conditions: -2
- Quality antibiotics: +2
- Expired/poor drugs: -2
- Medical skill 4+: +2
- Assistant: +1

### 4. Advanced Intervention (6-24 hours)
**Actions Available:**
- Surgical debridement (cutting away infected tissue)
- Blood transfusion to reduce pathogen load
- Experimental antiviral treatments (if available)
- Emergency amputation (extreme cases)

**Requirements:**
- Surgical facilities or exceptional field conditions
- Medical skill 5+ or qualified surgeon NPC
- Specialized equipment and supplies
- High risk to both patient and caregiver

**Surgical Debridement:**
- **Success (TN 15):** -4 to -5 CP, but -3 to -5 HP and trauma
- **Failure:** -1 CP, severe complications possible
- **Risk:** Caregiver exposure risk if patient 50%+ infected

**Blood Transfusion:**
- **Success (TN 16):** -5 to -8 CP, requires blood supply
- **Failure:** Patient may die from procedure
- **Risk:** High contamination risk for medical staff

**Experimental Antivirals:**
- **Success (TN 18):** -3 to -6 CP depending on drug quality
- **Availability:** Extremely rare, quest-level items
- **Side Effects:** May cause other complications

**Emergency Amputation:**
- **Limb bite only, within 5 minutes of bite**
- **Success (TN 12):** Removes ALL infection from that bite
- **Cost:** Permanent loss of limb, severe trauma, -5 HP
- **Risk:** May still have infection from other sources

## TREATMENT FAILURE CONSEQUENCES

### Time Window Failures
- **Miss 2-minute window:** Ongoing infection continues
- **Miss 1-hour window:** +1 CP penalty, harder to treat
- **Miss 6-hour window:** +2 CP penalty, infection advances
- **Miss 24-hour window:** +3 CP penalty, very difficult to reverse

### Botched Treatment Attempts
- **Critical Failure:** +1 to +2 CP from contamination
- **Wrong Procedure:** May worsen wound or add complications
- **Dirty Conditions:** Risk of secondary infection
- **Unqualified Attempts:** Higher failure chance, more severe consequences

## CAREGIVER INFECTION RISKS

### Treating Infected Patients
- **0-25% Patient:** No risk with basic precautions
- **26-50% Patient:** TN 12 to avoid exposure (+1 CP on failure)
- **51-75% Patient:** TN 15 to avoid exposure (+2 CP on failure)
- **76%+ Patient:** TN 18 to avoid exposure (+3 CP on failure)

### Risk Factors for Caregivers
- **Open wounds on caregiver:** -3 to safety rolls
- **No protective equipment:** -2 to safety rolls
- **Improvised protection:** +1 to safety rolls
- **Professional PPE:** +3 to safety rolls (very rare)
- **Medical training:** +1 per medical skill level

## SPECIAL INFECTION RULES

### Co-op Infection Dynamics
- **Hidden Information:** Players may attempt to hide infection
- **Symptoms Observable:** Higher stages become obvious
- **Trust Issues:** Infected players may become desperate
- **Treatment Cooperation:** Treating partner carries risks

### Environmental Factors
- **Dublin Weather:** Cold rain worsens infection progress
- **Seasonal Effects:** Winter conditions slow healing
- **Indoor Heating:** Proper warmth aids recovery
- **Stress Factors:** Combat/fear may accelerate infection

### Immunity and Resistance
- **No Natural Immunity:** Everyone is susceptible
- **Endurance Bonus:** High END gives small resistance bonus
- **Previous Exposure:** Surviving infection gives no immunity
- **Age Factors:** Very young/old may progress faster

## INFECTION ECONOMY

### Medical Supply Scarcity
- **Antibiotics:** Extremely valuable, trade commodity
- **First Aid Kits:** Limited supplies, must be rationed
- **Pain Medication:** Helps treatment success, reduces trauma
- **IV Supplies:** Hospital/clinic only, cannot improvise

### Faction Medical Resources
- **Community Faction:** Basic medical care, skilled NPCs
- **Militia Faction:** Military medics, some advanced supplies
- **Trader Faction:** Expensive medical supplies for trade
- **Outcast Faction:** Black market medicine, risky quality

### Quest Integration
- **Medical Supply Runs:** Raids on hospitals/pharmacies
- **Rescue Missions:** Save skilled medical NPCs
- **Research Quests:** Search for experimental treatments
- **Trade Negotiations:** Barter for crucial medications

## ANTI-EXPLOIT MEASURES

### No Magical Cures
- **100% infection is always fatal** - no exceptions
- **Treatment requires proper resources and procedures**
- **Player declarations without resources are denied**
- **Time limits are strictly enforced**

### Resource Tracking
- **Every medical supply use is tracked**
- **Cannot conjure antibiotics from thin air**
- **Expired medications have reduced effectiveness**
- **Equipment degrades with use**

### Realistic Limitations
- **Doctors cannot perform miracles without equipment**
- **Field surgery in dirty conditions often fails**
- **Infection spreads realistically based on actions**
- **Environmental conditions always matter**

The infection system is designed to create tension while giving players realistic options to fight back against the zombie plague - if they act quickly, think strategically, and accept the costs involved.
