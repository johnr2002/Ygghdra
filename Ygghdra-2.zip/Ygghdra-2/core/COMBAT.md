
# YGDHRA COMBAT SYSTEM

## COMBAT BASICS

### Combat Options (Always Available)
1. **Attack** - Direct assault with weapon/fists
2. **Defend** - Focus on protection, gain defensive bonus
3. **Retreat** - Attempt to flee combat
4. **Custom Action** - Player describes tactical approach

### Combat Flow
1. **Initiative:** Agility + Perception determines action order
2. **Declare Actions:** All participants choose actions
3. **Resolve Actions:** Apply modifiers, roll dice, determine outcomes
4. **Apply Results:** Damage, status effects, position changes
5. **Check Morale:** NPCs may flee if overwhelmed

## WEAPON CATEGORIES

### Melee Weapons

**Unarmed Combat**
- Damage: STR/3 (minimum 1)
- Speed: Very Fast
- Special: Cannot be disarmed, always available

**Knives & Blades**
- **Kitchen Knife:** Damage 2, Fast, Concealable
- **Combat Knife:** Damage 3, Fast, Reliable
- **Machete:** Damage 4, Moderate, Good reach
- **Sword:** Damage 5, Moderate, Excellent reach (if found)

**Blunt Weapons**
- **Improvised (bottle, book):** Damage 1, May break on use
- **Baseball Bat:** Damage 3, Moderate speed, Common
- **Crowbar:** Damage 3, Slow, Also useful as tool
- **Sledgehammer:** Damage 5, Very Slow, Requires STR 4+

**Improvised Weapons**
- **Chair Leg:** Damage 2, Fast, Breaks on natural 1
- **Broken Glass:** Damage 2, Fast, Damages user on natural 1
- **Tools:** Varies by type (hammer=3, screwdriver=2, etc.)

### Ranged Weapons

**Handguns**
- **Pistol (.22):** Damage 3, Low noise, Common ammo
- **Service Pistol (9mm):** Damage 4, Moderate noise, Police/security
- **Revolver (.38):** Damage 4, Reliable, Slow reload

**Long Guns**
- **Hunting Rifle:** Damage 6, High noise, Long range, Rare ammo
- **Shotgun:** Damage 5 close/3 medium/1 long, Very high noise
- **Assault Rifle:** Damage 5, Full-auto option, Military only

**Thrown Weapons**
- **Rocks/Debris:** Damage 1, Silent, Unlimited ammo
- **Knives:** Damage 2, Silent, Lose weapon if missed
- **Molotov Cocktail:** Damage 3 + fire, Area effect, Crafted

**Bows & Crossbows**
- **Improvised Bow:** Damage 2, Silent, Craft arrows
- **Hunting Bow:** Damage 3, Silent, Specialized arrows
- **Crossbow:** Damage 4, Silent, Slow reload

## ARMOR AND PROTECTION

### Clothing Protection
- **Heavy Coat:** +1 vs bites, -1 AGI
- **Leather Jacket:** +2 vs bites, +1 vs cuts
- **Work Clothes:** +1 vs scrapes and cuts
- **Sports Padding:** +2 vs blunt trauma

### Improvised Armor
- **Duct Tape Reinforcement:** +1 protection, reduced mobility
- **Magazine/Cardboard Padding:** +1 vs bites, bulky
- **Multiple Layers:** +1 protection, -2 AGI

### Professional Gear (Rare)
- **Riot Gear:** +3 protection, -3 AGI, very bulky
- **Bulletproof Vest:** +4 vs firearms, +1 vs other, -1 AGI
- **Military Gear:** +3 protection, +1 AGI, extremely rare

## COMBAT DIFFICULTY SCALING

### Single Zombie Encounters
- **Fresh Zombie (Days 1-7):** TN 10, 8 HP, slow but persistent
- **Decayed Zombie (Days 8-30):** TN 12, 6 HP, unpredictable movement
- **Skeletal Zombie (Days 31+):** TN 14, 4 HP, fast and aggressive

### Multiple Enemy Modifiers
- **2 Enemies:** -2 to all combat rolls
- **3 Enemies:** -4 to all combat rolls
- **4+ Enemies:** -6 to all combat rolls (near impossible)
- **Surrounded:** Additional -2 penalty
- **Horde (10+):** Retreat strongly recommended, TN 20+ to fight

### Environmental Combat Modifiers
- **High Ground:** +2 to attack rolls
- **Cover:** +3 to defense rolls
- **Narrow Space:** Negates some multi-enemy penalties
- **Slippery Surface:** -2 to AGI-based actions
- **Darkness:** -3 to accuracy, +2 to stealth
- **Loud Environment:** Masks noise, allows surprise

## INJURY SYSTEM

### Wound Severity Levels

**Scratch (1 HP damage)**
- Minor cuts, bruises, superficial wounds
- No mechanical effect
- Heals in 1-2 days
- Small infection risk if from zombie

**Minor Wound (2-3 HP damage)**
- Deeper cuts, painful bruises, minor burns
- -1 to related actions (arm wound = manipulation penalty)
- Heals in 3-5 days with care
- Moderate infection risk if from zombie

**Serious Wound (4-6 HP damage)**
- Deep gashes, broken fingers, muscle damage
- -2 to related actions, possible bleeding
- Heals in 1-2 weeks with medical care
- High infection risk, requires treatment

**Critical Wound (7+ HP damage)**
- Life-threatening injuries, major trauma
- -3 to all actions, significant bleeding
- May cause unconsciousness (END roll TN 15)
- Requires immediate medical attention or may worsen

### Specific Injury Types

**Head Injuries**
- Concussion: -2 to INT and PER for 24-48 hours
- Skull Fracture: Risk of death, requires surgery
- Eye Injury: Permanent -2 to PER if untreated

**Limb Injuries**
- **Broken Arm:** Cannot use arm, -4 to two-handed actions
- **Broken Leg:** Movement speed halved, -3 to AGI actions
- **Dislocated Joint:** -3 to use that limb until reset

**Torso Injuries**
- **Broken Ribs:** -2 to all physical actions, pain with movement
- **Internal Bleeding:** Lose 1 HP per hour until treated
- **Punctured Lung:** -3 to all actions, difficult breathing

### Blood Loss System
- **Light Bleeding:** Lose 1 HP per 6 hours until bandaged
- **Heavy Bleeding:** Lose 1 HP per hour until pressure applied
- **Severe Bleeding:** Lose 1 HP per 10 minutes, requires surgery
- **Arterial Bleeding:** Lose 1 HP per minute, death in minutes

### Shock and Trauma
- **Physical Shock:** Major injuries may cause unconsciousness
- **Pain Shock:** Severe pain causes -2 to all actions
- **Blood Loss Shock:** Below 25% HP = risk of unconsciousness
- **Adrenaline:** First round of combat ignores pain penalties

## COMBAT TACTICS AND SPECIAL ACTIONS

### Attack Options
- **All-Out Attack:** +2 damage, -2 defense until next turn
- **Aimed Attack:** +2 accuracy, -2 damage, targets specific location
- **Power Attack:** +2 damage with melee, -2 accuracy
- **Quick Attack:** +2 initiative next round, -1 damage

### Defense Options
- **Full Defense:** +4 to all defense rolls, cannot attack
- **Dodge:** +2 to avoid attacks, -1 to own accuracy
- **Block/Parry:** +3 to defense with weapon/shield
- **Take Cover:** +5 to defense vs ranged, may block movement

### Special Combat Actions
- **Disarm:** Target enemy weapon (TN 15), requires melee range
- **Trip/Knock Down:** Target enemy balance (TN 12), +2 vs prone targets
- **Grapple:** Prevent enemy movement, both limited actions
- **Called Shot:** Target specific body part, +5 TN, extra effect

### Environmental Usage
- **Push into Hazard:** Shove enemy into fire, off building, etc.
- **Use Terrain:** Fight from stairs, through doorway, around corner
- **Improvised Weapons:** Grab nearby objects as weapons
- **Escape Routes:** Always consider retreat options

## NOISE AND STEALTH COMBAT

### Noise Levels
- **Silent:** Unarmed combat, knives, bows
- **Quiet:** Melee weapons, suppressed firearms  
- **Moderate:** Most combat, breaking objects
- **Loud:** Firearms, explosions, screaming
- **Very Loud:** Shotguns, rifle fire, breaking glass

### Noise Consequences
- **Silent:** No additional attention
- **Quiet:** May attract nearby enemies (TN 15)
- **Moderate:** Attracts attention within 2 blocks (TN 12)
- **Loud:** Attracts attention within 5 blocks (TN 8)
- **Very Loud:** Draws zombies from across district (TN 5)

### Stealth Kills
- **Requirements:** Surprise, appropriate weapon, successful stealth
- **TN Modifier:** +3 to attack roll for stealth kill attempt
- **Success:** Instant kill vs unaware zombie/human
- **Failure:** Normal combat begins, lose surprise

## CO-OP COMBAT TACTICS

### Coordinated Actions
- **Flank Attack:** One distracts while other attacks from behind (+3)
- **Combined Attack:** Both attack same target (+2 each)
- **Cover Fire:** One provides suppression while other moves (+2)
- **Rescue:** One player saves other from grapple/surrounded

### Communication
- **Clear Orders:** Bonus to coordination if players specify plan
- **Split Attention:** Penalty if trying to fight separate groups
- **Mutual Aid:** Players can provide first aid during combat lulls

## SPECIAL SITUATIONS

### Fighting While Injured
- **Light Wounds:** -1 to combat effectiveness
- **Serious Wounds:** -2 to combat, risk of worsening injury
- **Critical Wounds:** -3 to combat, may collapse during fight

### Fighting While Infected
- **25% Infection:** -1 to all combat actions
- **50% Infection:** -2 to all actions, possible hallucinations
- **75% Infection:** -3 to all actions, severe symptoms affect combat

### Weapon Durability
- **Improvised Weapons:** Break on natural 1 attack roll
- **Poor Quality:** Break on natural 1-2
- **Standard Weapons:** Break only on critical failures
- **Quality Weapons:** Very rarely break, can be repaired

### Ammunition Scarcity
- **Track Every Round:** Ammunition is precious resource
- **Reload Time:** Takes full action to reload most weapons
- **Finding Ammo:** Rare and valuable, guard carefully
- **Improvised Ammunition:** Reduced effectiveness, may jam weapon

Combat in Ygdhra should be desperate, dangerous, and costly - even victories come with a price.
