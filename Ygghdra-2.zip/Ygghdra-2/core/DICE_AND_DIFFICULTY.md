
# YGDHRA DICE AND DIFFICULTY SYSTEM

## CORE DICE MECHANICS

### Virtual d20 System
- Base roll: 1-20 (simulated, vary outcomes realistically)
- Add relevant skill modifier (+0 to +5 typically)
- Add situational modifiers (-3 to +3)
- Compare to Target Number (TN)

### Target Number Ladder
- **Trivial:** TN 5 (basic survival tasks)
- **Easy:** TN 8 (simple actions with tools)
- **Moderate:** TN 12 (standard challenges)
- **Hard:** TN 15 (dangerous or complex tasks)
- **Very Hard:** TN 18 (expert-level challenges)
- **Extreme:** TN 20+ (near-impossible actions)

### Critical Results
- **Natural 1:** Automatic failure + complication
- **Natural 20:** Automatic success + bonus effect
- **Beat TN by 10+:** Major success
- **Fail by 10+:** Major failure with consequences

## SKILL MODIFIERS

### Skill Levels (0-5 scale)
- **0 - Untrained:** No modifier, -2 on complex tasks
- **1 - Novice:** +1 modifier
- **2 - Practiced:** +2 modifier  
- **3 - Skilled:** +3 modifier
- **4 - Expert:** +4 modifier
- **5 - Master:** +5 modifier

### Primary Skills
- **Combat (Melee):** Hand-to-hand, knives, clubs
- **Combat (Firearms):** Guns, bows, thrown weapons
- **Medical:** First aid, surgery, infection treatment
- **Mechanical:** Repairs, crafting, electronics
- **Stealth:** Sneaking, hiding, silent kills
- **Athletics:** Climbing, running, swimming
- **Survival:** Foraging, navigation, shelter
- **Social:** Persuasion, intimidation, leadership

## SITUATIONAL MODIFIERS

### Environmental Conditions
- **Excellent lighting:** +2
- **Good lighting:** +1
- **Dim lighting:** -1
- **Darkness:** -3
- **Pitch black:** -5

### Weather Effects
- **Clear weather:** No modifier
- **Light rain:** -1 to most actions
- **Heavy rain:** -2, infection treatment -1 effectiveness
- **Storm:** -3, travel dangerous
- **Fog:** -2 perception, +2 stealth
- **Cold:** -1 to all actions, stamina drain +25%

### Equipment Modifiers
- **Proper tools:** +2 to +3
- **Improvised tools:** +1
- **Wrong tools:** -1 to -2
- **No tools:** -2 to -3 (where tools expected)
- **Broken equipment:** -1 to -5 depending on damage

### Physical Condition
- **Healthy:** No modifier
- **Tired:** -1 to all actions
- **Exhausted:** -2 to all actions
- **Wounded (Minor):** -1 to physical actions
- **Wounded (Serious):** -2 to physical actions
- **Wounded (Critical):** -3 to all actions
- **Infected (25%+):** -1 to all actions
- **Infected (50%+):** -2 to all actions, hallucinations possible
- **Infected (75%+):** -3 to all actions, major symptoms

## COMBAT DIFFICULTY SCALING

### Zombie Combat TNs
- **1 Fresh Zombie:** TN 10 (Easy-Moderate)
- **1 Decayed Zombie:** TN 12 (Moderate) 
- **2 Zombies:** TN 15 (Hard)
- **3+ Zombies:** TN 18+ (Very Hard to Extreme)
- **Horde (10+):** TN 25+ (Impossible without tactics)

### Combat Modifiers
- **Surprise attack:** +3
- **High ground:** +2
- **Weapon advantage:** +1 to +3
- **Outnumbered 2:1:** -2
- **Outnumbered 3:1:** -4
- **Surrounded:** -5
- **Panicked:** -3
- **Coordinated attack:** +2 (co-op)

## INFECTION TREATMENT TNs

### Treatment Difficulty by Stage
- **0-25% Infection:** TN 8 (Easy)
- **26-50% Infection:** TN 12 (Moderate)
- **51-75% Infection:** TN 15 (Hard)
- **76-90% Infection:** TN 18 (Very Hard)
- **91-99% Infection:** TN 22 (Extreme)

### Treatment Window Modifiers
- **Immediate (0-2 min):** +2 bonus
- **Early (2-60 min):** +1 bonus
- **Golden Hour (1-6 hrs):** No modifier
- **Late (6-24 hrs):** -2 penalty
- **Too Late (24+ hrs):** -5 penalty

### Environment Modifiers for Treatment
- **Sterile facility:** +3
- **Clean indoor area:** +1
- **Outdoor shelter:** -1
- **Exposed/dirty area:** -3
- **Combat conditions:** -5

## TRAVEL AND EXPLORATION TNs

### Navigation Challenges
- **Familiar area:** TN 8
- **Known route:** TN 10
- **New area, clear path:** TN 12
- **New area, obstacles:** TN 15
- **Lost/poor visibility:** TN 18

### Stealth Movement
- **Open area, daylight:** TN 15
- **Urban cover, daylight:** TN 12
- **Indoor areas:** TN 10
- **Darkness bonus:** +2
- **Moving slowly:** +1
- **Large group:** -2 per extra person

## NPC INTERACTION TNs

### Persuasion/Social
- **Friendly NPC:** TN 8
- **Neutral NPC:** TN 12
- **Suspicious NPC:** TN 15
- **Hostile NPC:** TN 18
- **Enemy:** TN 20+

### Social Modifiers
- **Good reputation:** +2
- **Helped them before:** +3
- **Threatening appearance:** -2
- **Obviously infected:** -5
- **Offering resources:** +2 to +4
- **Armed while talking:** -1 to -3

## RANDOM ENCOUNTER FREQUENCY

### Travel Encounter Checks (per hour traveled)
- **Safe areas:** TN 18 (rare encounters)
- **Low-risk areas:** TN 15 (occasional)
- **Moderate-risk areas:** TN 12 (regular)
- **High-risk areas:** TN 9 (frequent)
- **Death zones:** TN 6 (constant danger)

### Base Attack Frequency (daily check)
- **No defense:** TN 8 (very likely)
- **Basic defense:** TN 12 (moderate chance)
- **Good defense:** TN 15 (low chance)
- **Excellent defense:** TN 18 (rare)

## OUTCOME VARIATION GUIDELINES

### Success Degrees
- **Barely Made It:** Meet TN exactly - success with minor cost
- **Solid Success:** Beat TN by 2-4 - clean success
- **Great Success:** Beat TN by 5-9 - bonus benefit
- **Legendary Success:** Beat TN by 10+ - exceptional outcome

### Failure Consequences
- **Close Failure:** Miss TN by 1-2 - minor setback
- **Clear Failure:** Miss TN by 3-5 - significant consequence
- **Bad Failure:** Miss TN by 6-9 - major problem
- **Catastrophic Failure:** Miss TN by 10+ - disaster plus complication

## REALISM ENFORCEMENT

### Impossible Actions (Auto-Fail)
- Actions without proper tools/resources
- Physics-defying stunts
- Knowledge the character wouldn't have
- Skills far beyond character capability

### Variable Difficulty
- Don't make every roll the same TN
- Adjust for player creativity and tactics
- Reward good planning with easier TNs
- Punish reckless behavior with harder TNs
- Consider cumulative effects (fatigue, wounds, stress)

### Balance Guidelines
- Early game: mostly TN 8-12 for basic survival
- Mid game: TN 12-15 for developed challenges  
- Late game: TN 15-18+ for major obstacles
- Always allow tactical options to reduce difficulty
- Never make survival purely luck-based
