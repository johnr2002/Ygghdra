
# YGDHRA INVENTORY AND CRAFTING SYSTEM

## INVENTORY MECHANICS

### Carrying Capacity
- **Base Capacity:** STR x 20 pounds comfortable load
- **Maximum Load:** STR x 30 pounds (moves at half speed, -2 AGI)
- **Overloaded:** Cannot carry more than maximum load
- **Bulk Items:** Some items take extra "space" regardless of weight

### Weight Categories
- **Tiny (0.1 lbs):** Pills, coins, small electronics
- **Small (0.5 lbs):** Smartphone, knife, bandages  
- **Medium (2 lbs):** Handgun, water bottle, tool
- **Large (8 lbs):** Rifle, backpack, first aid kit
- **Heavy (20+ lbs):** Car battery, large toolbox, fuel container

### Container System
- **Pockets:** 2-4 small items depending on clothing
- **Backpack:** +15 pound capacity, organized storage
- **Duffel Bag:** +25 pound capacity, awkward to carry (-1 AGI)
- **Shopping Cart:** +50 pounds but cannot enter buildings
- **Vehicle Storage:** Major capacity increase when available

## PROVENANCE ENFORCEMENT

### Acquisition Tracking
**Every item must have a realistic source:**
- **Starting Equipment:** Defined by character background
- **Looted Items:** Found at logical locations
- **Traded Items:** Obtained from NPCs at fair cost
- **Crafted Items:** Made from available components
- **Given Items:** Received from NPCs as reward/gift

### Anti-Exploit Rules
- **No Conjuring:** Players cannot claim items not explicitly acquired
- **Location Logic:** Items must come from appropriate places
- **Realistic Quantities:** Cannot find unlimited resources
- **Time Requirements:** Complex acquisitions take time
- **Skill Requirements:** Some items require knowledge to identify/use

### Acquisition Examples
**ALLOWED:**
- "I search the pharmacy for medicine" → Find antibiotics
- "I check the police station armory" → Find ammunition
- "I scavenge the auto shop" → Find tools and parts

**DENIED:**
- "I use my poison" (never acquired poison)
- "I pull out my satellite phone" (not established in setting)
- "I have military explosives" (no realistic acquisition source)

## WEAPON AND EQUIPMENT DEGRADATION

### Durability System
- **Excellent:** Functions perfectly, no penalties
- **Good:** Minor wear, no mechanical effects yet
- **Fair:** Noticeable wear, -1 to effectiveness
- **Poor:** Significant damage, -2 to effectiveness
- **Broken:** Non-functional, requires major repair

### Degradation Causes
- **Combat Use:** Weapons degrade with use, especially improvised ones
- **Environmental Damage:** Rain, dirt, neglect cause wear
- **Poor Maintenance:** Lack of cleaning/care accelerates damage
- **Overuse:** Using tools beyond intended purpose
- **Critical Failures:** Natural 1 rolls may damage equipment

### Specific Degradation Examples
**Firearms:**
- Jamming from dirt/poor maintenance
- Trigger/firing pin damage from overuse
- Barrel wear affecting accuracy
- Magazine springs weakening

**Melee Weapons:**
- Blade dulling and chipping
- Handle loosening or breaking
- Improvised weapons breaking entirely
- Metal fatigue from repeated impacts

**Medical Supplies:**
- Bandages getting dirty/contaminated
- Medications expiring or degrading
- Equipment breaking from rough handling
- Batteries dying in electronic devices

## BASIC CRAFTING SYSTEM

### Crafting Requirements
- **Materials:** Appropriate components for the item
- **Tools:** Necessary equipment for construction
- **Skill:** Relevant skill level for complexity
- **Time:** Realistic construction duration
- **Workspace:** Appropriate environment for the task

### Simple Crafting (No Skill Required)
**Molotov Cocktail:**
- Materials: Glass bottle, flammable liquid, cloth rag
- Time: 5 minutes
- Effect: 3 damage + fire, area effect
- Risk: May explode prematurely on natural 1

**Improvised Bandage:**
- Materials: Clean cloth, tape/string
- Time: 2 minutes  
- Effect: +1 to first aid attempts
- Limitation: Single use only

**Noise Maker/Alarm:**
- Materials: Cans, string/wire
- Time: 15 minutes
- Effect: Alerts to intrusion within 20 feet
- Limitation: One-time use, easily bypassed

**Barricade:**
- Materials: Furniture, boards, nails
- Time: 30-60 minutes depending on size
- Effect: +2 to base defense rating
- Requirement: Appropriate tools

### Mechanical Skill Crafting

**Skill Level 1-2:**
- **Improvised Tools:** Create basic tools from scrap
- **Simple Repairs:** Fix broken handles, patch holes
- **Basic Traps:** Tripwires, noise makers
- **Weapon Maintenance:** Clean and maintain equipment

**Skill Level 3-4:**
- **Advanced Repairs:** Fix complex mechanical items
- **Weapon Modifications:** Add scopes, silencers (with parts)
- **Electronics Repair:** Fix radios, flashlights
- **Vehicle Maintenance:** Basic car/bike repairs

**Skill Level 5+:**
- **Complex Devices:** Build generators, communication equipment
- **Vehicle Modification:** Armor plating, ram bars
- **Advanced Weapons:** Crossbows, compound bows
- **Electrical Systems:** Wiring, power distribution

### Medical Skill Crafting

**Skill Level 1-2:**
- **Improvised First Aid:** Create bandages, splints
- **Herbal Medicine:** Basic pain relief from plants
- **Sterilization:** Properly clean medical equipment
- **Field Dressings:** Improve wound care effectiveness

**Skill Level 3-4:**
- **Advanced Splints:** Professional-quality bone setting
- **Medication Preparation:** Mix/dilute drugs properly
- **Surgical Kits:** Assemble sterile surgical tools
- **IV Preparation:** Set up fluid replacement therapy

**Skill Level 5+:**
- **Pharmaceutical Compounding:** Create medications from components
- **Advanced Surgery Prep:** Sterile operating environments
- **Medical Device Repair:** Fix complex medical equipment
- **Prosthetics:** Create basic replacement limbs

## RESOURCE MANAGEMENT

### Consumable Tracking
**Food and Water:**
- Track individual meals and water bottles
- Spoilage times for different food types
- Nutritional quality affects health recovery
- Contaminated food/water risks infection

**Ammunition:**
- Count every round fired
- Different calibers not interchangeable  
- Reloading requires appropriate magazines
- Damaged ammunition may cause jams

**Medical Supplies:**
- Single-use items consumed on use
- Reusable items may degrade with use
- Expiration dates affect effectiveness
- Sterilization required for repeated use

**Fuel and Power:**
- Gasoline for vehicles and generators
- Battery power for electronics
- Propane for heating and cooking
- Matches/lighters for fire starting

### Scavenging Guidelines

**Residential Areas:**
- Basic food, water, first aid supplies
- Tools, sports equipment, knives
- Clothing, blankets, personal items
- Limited quantities, already partially looted

**Commercial Areas:**
- Specialized equipment for business type
- Larger quantities but more dangerous
- May require breaking/entering skills
- Higher chance of encountering other scavengers

**Industrial Areas:**
- Heavy tools, construction materials
- Chemicals (some useful, some dangerous)
- Vehicles and mechanical parts
- Often require technical knowledge to use

**Medical Facilities:**
- Advanced medical supplies and equipment
- Pharmaceuticals (if not already looted)
- Extremely dangerous due to infection concentration
- May contain valuable research materials

## ITEM CATEGORIES AND VALUES

### Trade Value Economy
**Tier 1 - Common (Low Value):**
- Basic food, water, simple clothing
- Improvised tools, scrap materials
- Low-end medical supplies (bandages)

**Tier 2 - Useful (Moderate Value):**
- Quality tools, durable clothing
- Basic weapons, simple electronics
- Standard medical supplies, preserved food

**Tier 3 - Valuable (High Value):**
- Firearms, ammunition, advanced tools
- Professional medical equipment
- Specialized survival gear, vehicles

**Tier 4 - Precious (Extreme Value):**
- Antibiotics, advanced medications
- Military equipment, vehicles with fuel
- High-tech electronics, rare materials

### Faction-Specific Values
**Community Faction:**
- Values: Medical supplies, building materials, food
- Has: Basic tools, labor, safety in numbers
- Trades: Services for specialized goods

**Trader Faction:**
- Values: Anything with resale value
- Has: Diverse inventory, transportation
- Trades: Complex barter arrangements

**Militia Faction:**
- Values: Weapons, ammunition, intelligence
- Has: Security, military equipment
- Trades: Protection for supplies

**Outcast Faction:**
- Values: Anything useful for survival
- Has: Street knowledge, hidden resources
- Trades: Information and black market goods

## SPECIAL ITEM CATEGORIES

### Quest Items
- **Research Data:** Information about zombie virus
- **Key Cards:** Access to secure facilities
- **Personal Items:** Important to specific NPCs
- **Prototype Equipment:** Experimental technology

### Unique Items
- **Military Radio:** Long-range communication
- **Medical Scanner:** Advanced diagnostic equipment
- **Survivor Journal:** Contains valuable survival tips
- **Vehicle Keys:** Access to specific vehicles

### Dangerous Items
- **Unstable Chemicals:** May explode or poison
- **Contaminated Equipment:** High infection risk
- **Damaged Electronics:** May malfunction dangerously
- **Improvised Explosives:** Risky to transport/use

## STORAGE AND BASE INTEGRATION

### Personal Storage
- **On Person:** Limited by carrying capacity
- **Vehicle:** Secure mobile storage when available
- **Cache:** Hidden supply stashes in the world
- **Room/Shelter:** Personal space in established base

### Base Storage Systems
- **Communal Supplies:** Shared faction resources
- **Personal Lockers:** Individual secure storage
- **Workshop Areas:** Tool and equipment storage
- **Medical Bay:** Sterile supply storage
- **Armory:** Weapon and ammunition security

### Storage Security
- **Locked Containers:** Require keys or lock picking
- **Hidden Caches:** Must remember/mark locations
- **Guard Duty:** NPCs can protect stored items
- **Inventory Theft:** Other survivors may steal unguarded items

The inventory system emphasizes realism, scarcity, and the constant struggle to maintain equipment in a collapsed world while preventing players from claiming resources they haven't actually acquired through gameplay.
