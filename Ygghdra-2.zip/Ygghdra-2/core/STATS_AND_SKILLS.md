
# YGDHRA STATS AND SKILLS SYSTEM

## PRIMARY ATTRIBUTES (1-10 Scale)

### Strength (STR)
**Effects:**
- Melee damage: +1 damage per 2 STR above 2
- Carrying capacity: STR x 20 pounds comfortable load
- Physical tasks: Breaking doors, moving obstacles
- Intimidation: +1 per 3 STR above 2

**Examples:**
- STR 2: Frail, struggles with heavy bags
- STR 4: Average adult strength
- STR 6: Athletic, can break weak doors
- STR 8: Very strong, can move furniture alone
- STR 10: Exceptional strength, can bend metal bars

### Endurance (END)
**Effects:**
- Health Points: END x 3 + 5
- Stamina: END x 2 + STR + 10
- Disease resistance: +1 per 2 END above 2 to infection resistance
- Recovery speed: Higher END heals wounds faster

**Examples:**
- END 2: Sickly, tires easily, HP 11, low stamina
- END 4: Average health, HP 17
- END 6: Hardy constitution, HP 23
- END 8: Very healthy, rarely sick, HP 29
- END 10: Iron constitution, HP 35, disease resistant

### Agility (AGI)
**Effects:**
- Initiative: Act first in combat/crisis
- Stealth: +1 per 2 AGI above 2
- Dodge: Avoid attacks in combat
- Fine motor skills: Lock picking, electronics

**Examples:**
- AGI 2: Clumsy, slow reflexes
- AGI 4: Average coordination
- AGI 6: Quick reflexes, good balance
- AGI 8: Very agile, cat-like reflexes
- AGI 10: Exceptional grace and speed

### Intelligence (INT)
**Effects:**
- Skill learning: +25% XP gain per 2 INT above 2
- Crafting: Complex items require minimum INT
- Medicine: Advanced treatments need high INT
- Problem solving: Notice patterns, solve puzzles

**Examples:**
- INT 2: Slow learner, basic understanding
- INT 4: Average intelligence
- INT 6: Above average, good problem solver
- INT 8: Very intelligent, quick learner
- INT 10: Genius level, exceptional insight

### Perception (PER)
**Effects:**
- Awareness: Spot hidden threats, items, clues
- Ranged accuracy: +1 per 2 PER above 2
- First aid: Notice injury severity
- Social reading: Detect lies, mood

**Examples:**
- PER 2: Oblivious, misses obvious details
- PER 4: Average awareness
- PER 6: Alert, notices most things
- PER 8: Very observant, spots subtle clues
- PER 10: Exceptional awareness, nothing escapes notice

### Charisma (CHA)
**Effects:**
- Social interactions: +1 per 2 CHA above 2
- Leadership: Convince NPCs to follow
- Animal handling: Calm aggressive animals
- Inspiration: Boost companion morale

**Examples:**
- CHA 2: Awkward, off-putting personality
- CHA 4: Average social skills
- CHA 6: Likeable, natural social ease
- CHA 8: Very charismatic, natural leader
- CHA 10: Exceptional presence, inspiring to others

## DERIVED STATISTICS

### Health Points (HP)
- **Formula:** Endurance x 3 + 5
- **Function:** Physical condition, consciousness, life
- **Death:** 0 HP = unconscious and dying, -5 HP = death
- **Recovery:** 1 HP per day with rest, 2 HP with medical care

### Stamina
- **Formula:** Endurance x 2 + Strength + 10
- **Function:** Physical and mental energy for actions
- **Usage:** Combat actions, running, strenuous work
- **Recovery:** 1 point per 10 minutes rest, full recovery after 8 hours sleep

### Sanity/Stress (Optional)
- **Range:** 0-100 (100 = stable, 0 = complete breakdown)
- **Loss triggers:** Witnessing death, killing, isolation, injury
- **Effects:** Below 50 = occasional penalties, below 25 = frequent problems
- **Recovery:** Rest, social support, achieving goals, safety

## SKILLS SYSTEM (0-10 Scale)

### Combat Skills

**Combat (Melee)**
- **0:** Never been in a fight
- **2:** Basic self-defense knowledge  
- **4:** Competent with simple weapons
- **6:** Skilled fighter, knows techniques
- **8:** Expert combatant, multiple weapon types
- **10:** Master warrior, legendary skill

**Combat (Firearms)**
- **0:** Never held a gun
- **2:** Basic gun safety, can fire accurately at close range
- **4:** Competent shooter, handles recoil well
- **6:** Skilled marksman, good at longer ranges
- **8:** Expert shooter, quick draw, multiple weapon types
- **10:** Master sniper, can make impossible shots

### Survival Skills

**Medical**
- **0:** Basic first aid only
- **2:** Can clean and bandage wounds properly
- **4:** Handles serious injuries, knows infection signs
- **6:** Skilled field medic, can perform minor surgery
- **8:** Expert medic, major surgery, disease treatment
- **10:** Master surgeon, can handle any medical crisis

**Mechanical**
- **0:** Can't fix anything complex
- **2:** Basic repairs, simple tools
- **4:** Can repair most common items
- **6:** Skilled with electronics and machinery
- **8:** Expert technician, can build complex devices
- **10:** Master engineer, can create new inventions

**Stealth**
- **0:** Loud, clumsy movement
- **2:** Can move quietly when careful
- **4:** Good at hiding and sneaking
- **6:** Skilled infiltrator, hard to detect
- **8:** Expert stealth, can disappear in plain sight
- **10:** Master of stealth, ghost-like movement

**Athletics**
- **0:** Out of shape, poor physical condition
- **2:** Basic fitness, can run short distances
- **4:** Good condition, decent at physical activities
- **6:** Athletic, good at climbing, swimming
- **8:** Excellent athlete, parkour abilities
- **10:** Exceptional physical abilities, Olympic level

**Survival**
- **0:** City person, helpless in wilderness
- **2:** Basic camping knowledge
- **4:** Can find food and shelter in nature
- **6:** Skilled outdoorsman, weather prediction
- **8:** Expert survivor, can thrive anywhere
- **10:** Master of survival, can live off any environment

**Social**
- **0:** Socially awkward, poor communication
- **2:** Basic conversation skills
- **4:** Good at reading people, persuasive
- **6:** Skilled negotiator, natural leadership
- **8:** Expert manipulator, can convince almost anyone
- **10:** Master of human psychology, legendary charisma

## SKILL ADVANCEMENT

### Experience Gain
- **Successful Use:** +1 XP when skill used successfully
- **Critical Success:** +2 XP for exceptional results
- **Failure Learning:** +1 XP for learning from major failures
- **Training:** +5 XP per day with qualified instructor
- **Practice:** +1 XP per day dedicated practice (safe environment)

### Advancement Requirements
**Skill Level 0→1:** 10 XP
**Skill Level 1→2:** 20 XP  
**Skill Level 2→3:** 30 XP
**Pattern:** Each level requires 10 more XP than previous

### Advancement Caps
- **Attribute Limit:** Skill cannot exceed related attribute + 3
- **Training Limit:** Level 6+ requires instructor or special circumstances
- **Time Limit:** Maximum 1 skill level gain per week
- **Specialization:** After level 5, must choose specialization focus

### Skill Specializations (Level 6+)

**Combat (Melee) Specializations:**
- Knife Fighting: +2 with bladed weapons
- Blunt Weapons: +2 with clubs, bats, hammers
- Improvised Weapons: +2 with makeshift weapons
- Unarmed Combat: +2 to hand-to-hand fighting

**Combat (Firearms) Specializations:**
- Pistol Expert: +2 with handguns
- Rifle Expert: +2 with long guns
- Quick Draw: +2 initiative with weapons ready
- Moving Targets: +2 against moving enemies

**Medical Specializations:**
- Trauma Surgery: +2 to treating serious wounds
- Infection Control: +2 to treating diseases/infections
- Field Medicine: +2 when treating under pressure
- Pharmaceutical: +2 to drug identification and use

**Mechanical Specializations:**
- Electronics: +2 to electrical devices and systems
- Automotive: +2 to vehicle repair and operation
- Weapons Maintenance: +2 to weapon repair and modification
- Construction: +2 to building and fortification

## SKILL SYNERGIES

### Related Skill Bonuses
- **Medical + Intelligence:** +1 to complex treatments
- **Stealth + Agility:** +1 to moving silently
- **Social + Perception:** +1 to reading people's intentions
- **Mechanical + Intelligence:** +1 to understanding complex systems
- **Combat + Strength:** +1 damage with melee weapons
- **Firearms + Perception:** +1 accuracy at long range

### Tool and Equipment Bonuses
- **Professional Tools:** +2 to relevant skill checks
- **Quality Equipment:** +1 to skill checks
- **Improvised Tools:** -1 to skill checks
- **Broken Equipment:** -2 or impossible depending on task

## ATTRIBUTE ADVANCEMENT

### Rare Attribute Increases
- **Major Life Events:** Surviving extreme situations
- **Long-term Training:** Months of dedicated effort
- **Physical Changes:** Strength/Endurance through sustained labor
- **Mental Growth:** Intelligence through study and experience
- **Social Development:** Charisma through leadership experience

### Attribute Caps
- **Natural Maximum:** 8 for most humans
- **Exceptional Training:** Can reach 9 with extreme dedication
- **Legendary Status:** 10 only for the most exceptional individuals
- **Age Effects:** Attributes may decline with advanced age or injury

## CONDITION MODIFIERS

### Injury Effects
- **Light Wounds:** -1 to related physical actions
- **Moderate Wounds:** -2 to related actions
- **Serious Wounds:** -3 to related actions, possible skill restrictions
- **Critical Wounds:** -5 to all actions, severe restrictions

### Fatigue Effects  
- **Tired:** -1 to all actions
- **Exhausted:** -2 to all actions, stamina recovery halved
- **Dead on Feet:** -3 to all actions, risk of collapse

### Infection Effects
- **25% Infection:** -1 to all actions
- **50% Infection:** -2 to all actions, possible hallucinations
- **75% Infection:** -3 to all actions, severe symptoms
- **90%+ Infection:** -4 to all actions, near death

### Environmental Effects
- **Optimal Conditions:** +1 to +2 bonus
- **Difficult Conditions:** -1 to -2 penalty
- **Extreme Conditions:** -3 to -5 penalty
- **Impossible Conditions:** Automatic failure

This system provides depth while remaining manageable for AI implementation and player understanding.
