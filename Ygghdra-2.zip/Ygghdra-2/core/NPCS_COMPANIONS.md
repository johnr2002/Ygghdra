
# YGDHRA NPC AND COMPANION SYSTEM

## NPC GENERATION FRAMEWORK

### Core NPC Attributes
**Basic Information:**
- **Name:** Realistic Irish/international names for Dublin setting
- **Age:** Affects physical capability and life experience
- **Background:** Pre-apocalypse profession affecting skills
- **Personality Type:** Affects reactions and decision-making

**Physical Characteristics:**
- **Health:** Current HP and overall condition
- **Injuries:** Existing wounds or disabilities
- **Infection Status:** Current corruption level (hidden from player unless obvious)
- **Equipment:** Clothing, weapons, personal items

**Mental State:**
- **Stress Level:** Current psychological condition
- **Trauma History:** Past experiences affecting behavior
- **Motivations:** What drives their survival decisions
- **Fears:** Specific phobias or concerns

### NPC Skill Levels (Simplified Scale 0-3)
**Combat Effectiveness:**
- **0:** Civilian with no combat training
- **1:** Basic self-defense knowledge
- **2:** Competent fighter (police, military, athlete)
- **3:** Expert combatant (special forces, martial artist)

**Survival Skills:**
- **0:** City dweller with no outdoor experience  
- **1:** Basic camping/outdoor knowledge
- **2:** Experienced outdoorsman or professional
- **3:** Survival expert (ranger, guide, military)

**Medical Knowledge:**
- **0:** Basic first aid only
- **1:** Advanced first aid, some medical training
- **2:** Professional medical training (nurse, paramedic)
- **3:** Doctor or surgeon level expertise

**Technical Skills:**
- **0:** Basic tool use only
- **1:** Can perform simple repairs
- **2:** Skilled tradesperson (mechanic, electrician)
- **3:** Expert engineer or specialist

**Social Influence:**
- **0:** Poor social skills, awkward
- **1:** Average interpersonal abilities  
- **2:** Naturally charismatic or trained (teacher, salesperson)
- **3:** Natural leader or professional (politician, therapist)

## COMPANION RECRUITMENT

### Recruitment Opportunities
**Initial Encounters:**
- Lone survivor seeking help
- Member of family/group willing to join
- Specialist offering services for protection
- Refugee from overrun area

**Faction Deserters:**
- Disillusioned faction member
- Expelled from group for misconduct
- Fleeing political persecution
- Seeking better opportunities

**Rescued Individuals:**
- Freed from zombie trap/siege
- Liberated from hostile survivors
- Saved from medical emergency
- Protected during crisis event

### Recruitment Difficulty Factors
**NPC Desperation Level:**
- **High:** Will join almost anyone for safety
- **Medium:** Needs convincing or demonstration of competence
- **Low:** Very selective, high standards for joining

**Player Reputation:**
- **Unknown:** Must prove trustworthiness through actions
- **Positive:** Previous good deeds make recruitment easier
- **Negative:** Past bad actions create resistance

**Resource Situation:**
- **Player Well-Supplied:** Attractive to join for resources
- **Player Struggling:** Must offer other benefits (protection, skills)
- **Mutual Benefit:** Both parties gain from association

**Faction Conflicts:**
- **Allied Faction:** Easy recruitment if in good standing
- **Neutral Faction:** Standard difficulty
- **Enemy Faction:** Very difficult, may require defection scenario

### Recruitment Process
1. **Initial Contact:** First meeting and impression formation
2. **Trust Building:** Demonstrate reliability and competence
3. **Negotiation:** Discuss terms, expectations, roles
4. **Trial Period:** Temporary association before full commitment
5. **Full Recruitment:** Permanent companion status achieved

## LOYALTY SYSTEM (0-100 Scale)

### Loyalty Categories
**0-20 (Disloyal):**
- Actively looking for opportunity to leave/betray
- May steal supplies and abandon group
- Will not follow dangerous orders
- Potential for sabotage or information selling

**21-40 (Unreliable):**
- Stays for convenience but uncommitted
- May flee during dangerous situations
- Follows only safe, reasonable orders
- Requires constant supervision

**41-60 (Neutral):**
- Accepts group membership for mutual benefit
- Generally follows orders unless extreme risk
- May question leadership decisions
- Stable but not particularly loyal

**61-80 (Loyal):**
- Committed to group success and survival
- Follows most orders even with some risk
- Defends group against criticism
- Willing to take moderate risks for group

**81-100 (Devoted):**
- Completely committed to player/group
- Will follow orders into extreme danger
- Personal sacrifice for group welfare
- Considers player family/best friend

### Loyalty Gain Triggers (+5 to +15 points)
**Major Positive Actions:**
- Saving companion's life (+15)
- Sharing scarce medical supplies when companion injured (+10)
- Defending companion against accusations (+8)
- Including companion in important decisions (+5)
- Successful mission leadership (+5)

**Daily Positive Actions:**
- Fair resource distribution (+2)
- Treating companion with respect (+1)
- Listening to companion's concerns (+2)
- Sharing meals consistently (+1)
- Protecting companion during travel (+3)

### Loyalty Loss Triggers (-5 to -20 points)
**Major Negative Actions:**
- Abandoning companion in danger (-20)
- Stealing from companion (-15)
- Lying about serious matters (-10)
- Forcing companion into extremely dangerous situation (-8)
- Consistently making poor decisions that endanger group (-5)

**Daily Negative Actions:**
- Hoarding resources while companion goes without (-3)
- Dismissing companion's opinions (-2)
- Taking unnecessary risks that endanger group (-2)
- Failing to share information (-1)
- Generally rude or dismissive behavior (-1)

### Special Loyalty Modifiers
**Personality Compatibility:**
- **Perfect Match:** +25% to all loyalty gains
- **Good Compatibility:** +10% to all loyalty gains
- **Minor Conflicts:** -10% to all loyalty gains
- **Major Personality Clash:** -25% to all loyalty gains

**Shared Experiences:**
- **Survived Crisis Together:** +10 loyalty
- **Successful Long Mission:** +5 loyalty
- **Failed Mission:** -5 loyalty (unless player clearly tried their best)
- **Shared Trauma:** +15 loyalty (mutual support through difficulty)

## COMPANION BEHAVIOR SYSTEM

### Combat Behavior by Loyalty
**High Loyalty (61-100):**
- Fights alongside player even against superior odds
- Covers player's retreat if necessary
- Uses own medical supplies on player if needed
- Coordinates tactics effectively

**Medium Loyalty (41-60):**
- Fights competently against reasonable odds
- May retreat if situation becomes hopeless
- Shares resources fairly during combat
- Basic tactical cooperation

**Low Loyalty (0-40):**
- Flees at first sign of serious danger
- Protects own interests over group
- May abandon wounded player to save themselves
- Poor tactical coordination due to mistrust

### Social Interactions
**With Other NPCs:**
- High loyalty companions defend player's reputation
- Low loyalty companions may spread negative gossip
- Companion personality affects group dynamics
- Romantic relationships possible with high loyalty over time

**With Factions:**
- Companion background affects faction reception
- Some companions have faction connections (positive/negative)
- Loyal companions improve player's faction standing
- Disloyal companions may damage faction relationships

### Task Performance
**High Loyalty Tasks:**
- Performs assigned duties reliably
- Takes initiative on group-beneficial projects
- Works extra hours when needed
- Maintains equipment carefully

**Low Loyalty Task Performance:**
- Does minimum required work
- May sabotage tasks if loyalty extremely low
- Steals supplies if opportunity arises
- Poor quality work due to lack of caring

## COMPANION ADVANCEMENT

### Skill Improvement Rate
**Player Character:** 100% normal XP gain rate
**High Loyalty Companions (80+):** 75% XP gain rate
**Medium Loyalty Companions (40-79):** 50% XP gain rate  
**Low Loyalty Companions (0-39):** 25% XP gain rate

### Training Opportunities
**Player Teaching:** Can train companions in skills player has higher level
**NPC Specialists:** Other NPCs can provide training for resources/favors
**Experience Learning:** Companions gain skills through successful use
**Faction Training:** Some factions offer skill training to members

### Advancement Limitations
**Skill Caps:** Companions cannot exceed player's skill level through training
**Attribute Limits:** NPCs have fixed attributes (don't increase like player)
**Specialization Focus:** Companions develop along their natural inclinations
**Resource Requirements:** Advanced training requires time and materials

## COMPANION ARCHETYPES

### The Guardian (Combat Specialist)
**Background:** Military, police, security, or martial arts
**Skills:** High combat effectiveness, moderate survival
**Equipment:** Military gear, weapons, tactical knowledge
**Personality:** Protective, disciplined, follows orders well
**Loyalty Triggers:** Respect for authority, clear leadership, tactical competence

### The Healer (Medical Specialist)
**Background:** Doctor, nurse, paramedic, or first aid instructor
**Skills:** High medical knowledge, low combat effectiveness
**Equipment:** Medical supplies, pharmaceutical knowledge
**Personality:** Compassionate, risk-averse, values life
**Loyalty Triggers:** Protecting injured, ethical behavior, medical resource sharing

### The Engineer (Technical Specialist)
**Background:** Mechanic, electrician, computer technician, engineer
**Skills:** High technical skills, moderate survival
**Equipment:** Tools, technical manuals, repair materials
**Personality:** Problem-solver, practical, values efficiency
**Loyalty Triggers:** Respecting expertise, providing good tools, logical decisions

### The Scout (Survival Specialist)
**Background:** Hunter, park ranger, military scout, athlete
**Skills:** High survival and stealth, moderate combat
**Equipment:** Outdoor gear, navigation tools, hunting weapons
**Personality:** Independent, observant, comfortable with danger
**Loyalty Triggers:** Respecting autonomy, outdoor competence, fair treatment

### The Diplomat (Social Specialist)
**Background:** Teacher, salesperson, politician, social worker
**Skills:** High social influence, low combat/technical
**Equipment:** Communication devices, trade goods, cultural knowledge
**Personality:** Persuasive, optimistic, values cooperation
**Loyalty Triggers:** Peaceful solutions, fair treatment of others, democratic decisions

### The Survivor (Balanced Generalist)
**Background:** Ordinary citizen who adapted well to apocalypse
**Skills:** Moderate in all areas, no particular weakness
**Equipment:** Improvised gear, practical items, street knowledge
**Personality:** Adaptable, pragmatic, survivor mentality
**Loyalty Triggers:** Competent leadership, resource sharing, mutual respect

## NPC RELATIONSHIP DYNAMICS

### Inter-Companion Relationships
**Positive Relationships:**
- Shared background or interests create bonds
- Complementary skills lead to cooperation
- Mutual respect builds over time
- Romantic relationships may develop

**Negative Relationships:**
- Personality conflicts cause tension
- Resource competition creates friction
- Past history (faction conflicts, personal grudges)
- Jealousy over player attention or resources

**Relationship Effects:**
- Positive relationships improve group efficiency
- Negative relationships may cause companions to leave
- Player must mediate disputes to maintain group cohesion
- Group dynamics affect overall morale and performance

### Romantic Relationships
**Development Requirements:**
- High loyalty (80+) over extended time
- Compatible personalities and values
- Shared traumatic experiences creating bonds
- Player actively pursuing relationship

**Relationship Benefits:**
- Emotional support reduces stress
- Increased cooperation and resource sharing
- Stronger motivation to protect each other
- Potential for starting families (long-term survival)

**Relationship Complications:**
- Jealousy from other companions
- Distraction during dangerous situations
- Difficult decisions if partner becomes infected
- Grief and trauma if partner dies

## CO-OP COMPANION INTEGRATION

### Dual Player Dynamics
**NPC Loyalty Split:** Some NPCs may prefer one player over another
**Leadership Conflicts:** NPCs confused by conflicting orders from players
**Resource Mediation:** NPCs may ask players to resolve resource disputes
**Relationship Triangles:** NPCs may develop stronger bonds with one player

### Co-op Specific Rules
**Joint Commands:** Both players must agree for major NPC decisions
**Individual Relationships:** Each player builds separate loyalty with NPCs
**Faction Integration:** NPCs help facilitate faction relationships for both players
**Combat Coordination:** NPCs provide tactical support to both players

This NPC system creates meaningful relationships that evolve based on player actions while maintaining realistic human behavior in extreme survival situations.
