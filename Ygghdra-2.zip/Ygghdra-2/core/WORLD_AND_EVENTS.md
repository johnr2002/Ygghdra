
# YGDHRA WORLD AND EVENTS SYSTEM

## DUBLIN GEOGRAPHY AND LOCATIONS

### Key Dublin Districts and Landmarks
**City Center:**
- **Temple Bar:** Cultural quarter, pubs, cobblestone streets
- **Trinity College:** Historic university, large library, defensible courtyards
- **Grafton Street:** Main shopping district, high foot traffic pre-outbreak
- **Dublin Castle:** Government complex, potential faction stronghold
- **Christ Church Cathedral:** Historic building, potential shelter/faction base

**North Side:**
- **O'Connell Street:** Major thoroughfare, wide avenue with monuments
- **Phoenix Park:** Massive urban park, potential faction territory
- **Dublin Port:** Industrial area, shipping containers, potential resources
- **Croke Park:** Large stadium, potential refugee camp or horde concentration

**South Side:**
- **St. Stephen's Green:** Central park, open space with limited cover
- **University College Dublin:** Campus with multiple buildings
- **Rathmines:** Residential suburb, typical housing
- **Dún Laoghaire:** Coastal town, harbor access

**Outer Areas:**
- **Dublin Airport:** Major infrastructure, potential military presence
- **Industrial Estates:** Manufacturing, warehouses, technical resources
- **Residential Suburbs:** Family homes, shopping centers
- **Dublin Mountains:** Rural areas, potential escape routes

### Location-Specific Characteristics

**Urban Dense Areas (City Center):**
- High initial zombie concentration
- Complex building layouts with multiple levels
- Limited escape routes but many hiding spots
- Higher chance of encountering other survivors

**Residential Areas:**
- Moderate zombie concentration
- Family homes with basic supplies
- Neighborhood knowledge helps navigation
- Former residents may have emotional attachments

**Industrial Zones:**
- Lower initial zombie concentration
- Specialized equipment and vehicles
- Dangerous machinery and chemicals
- Often controlled by factions for resources

**Parks and Open Spaces:**
- Variable zombie concentration
- Good visibility but limited cover
- Seasonal changes affect usability
- Potential for temporary camps

## FACTION SYSTEM

### The Community (Temple Bar Base)
**Leadership:** Democratic council of elected representatives
**Population:** 200-400 survivors, fluctuates with recruitment/losses
**Territory:** Temple Bar cultural quarter, expanding slowly
**Resources:** Strong social organization, cultural preservation, limited military
**Goals:** Rebuild civilization, maintain democratic values, protect civilians

**Relationship Factors:**
- Values peaceful cooperation and democratic decision-making
- Welcomes new members who contribute positively
- Hostile to raiders and those who threaten civilians
- Neutral to military factions unless threatened

**Services Offered:**
- Medical care for civilians
- Education and skill training
- Democratic dispute resolution
- Cultural events and morale building

**Resource Needs:**
- Military protection against raiders
- Advanced medical supplies
- Technical expertise for infrastructure
- Reliable food production systems

### The Traders (Grafton Street Hub)
**Leadership:** Merchant council based on economic success
**Population:** 150-300 members, includes many transients
**Territory:** Grafton Street commercial district, mobile trade routes
**Resources:** Extensive trade networks, transportation, diverse goods
**Goals:** Restore economic stability, control trade routes, accumulate wealth

**Relationship Factors:**
- Values profitable trade relationships above ideology
- Welcomes anyone who brings valuable goods or services
- Neutral toward most factions unless trade is threatened
- Will trade with anyone who pays fair prices

**Services Offered:**
- Goods and services marketplace
- Transportation and courier services
- Information brokerage
- Banking and resource storage

**Resource Needs:**
- Security for trade routes
- Rare and valuable commodities
- Skilled artisans and technicians
- Reliable communication systems

### The Militia (Phoenix Park Garrison)
**Leadership:** Military hierarchy led by former Irish Defense Forces officers
**Population:** 100-250 personnel, strict membership requirements
**Territory:** Phoenix Park converted to military base, patrol routes
**Resources:** Military equipment, disciplined organization, tactical expertise
**Goals:** Restore order, eliminate zombie threat, establish military government

**Relationship Factors:**
- Values military discipline and following orders
- Recruits those with military/police background
- Hostile to anarchist groups and raiders
- Protective of civilian populations under their control

**Services Offered:**
- Military protection and escort services
- Tactical training and equipment
- Organized zombie clearing operations
- Law enforcement and justice system

**Resource Needs:**
- Advanced weaponry and ammunition
- Medical supplies for treating wounded
- Civilian specialists (doctors, engineers)
- Intelligence on zombie movements and threats

### The Outcasts (Underground Network)
**Leadership:** Anarchist collective with rotating leadership
**Population:** 50-200 members, difficult to track accurately
**Territory:** Dublin sewers, abandoned buildings, hidden locations
**Resources:** Underground knowledge, stealth capabilities, black market access
**Goals:** Individual freedom, resistance to authority, survival by any means

**Relationship Factors:**
- Values personal freedom and rejects authority
- Welcomes outcasts, criminals, and rebels
- Hostile to military and organized government factions
- Neutral or friendly to independent survivors

**Services Offered:**
- Black market goods and services
- Information on avoiding faction patrols
- Safe houses for those fleeing authority
- Underground transportation routes

**Resource Needs:**
- Weapons and equipment for guerrilla operations
- Medical supplies for treating injuries
- Food and basic survival necessities
- Communication equipment for coordination

## WORLD EVOLUTION TIMELINE

### Week 1: Initial Chaos (Days -2 to 5)
**Day -2 to 0:** Pre-outbreak tension, first infections, government response
**Day 1-3:** Zombie outbreak spreads, military quarantine attempts
**Day 4-7:** Government collapse, military units fragment, faction formation begins

**World State:**
- Emergency services still partially functional
- Military checkpoints established but failing
- Mass evacuation attempts creating chaos
- Initial survivor groups forming spontaneously

**Player Opportunities:**
- Access to government resources before collapse
- Recruit from military/police units
- Establish early territorial claims
- Form alliances before factional hardening

### Week 2-4: Faction Formation (Days 8-28)
**Week 2:** Military units establish bases, civilian groups organize
**Week 3:** Trade relationships develop, territorial boundaries emerge
**Week 4:** Faction identities solidify, diplomatic contact established

**World State:**
- Clear faction territories established
- Trade routes and communication networks developing
- Zombie populations consolidating into predictable patterns
- Resource scarcity driving faction competition

**Player Opportunities:**
- Join established factions or remain independent
- Establish base before good locations taken
- Develop reputation and relationships
- Access faction-specific resources and training

### Month 2-3: Stabilization (Days 29-90)
**Month 2:** Political alliances form, major infrastructure projects begin
**Month 3:** Trade agreements established, zombie threat becomes manageable

**World State:**
- Stable faction governments with clear policies
- Regular trade and diplomatic contact
- Organized zombie clearing operations
- Basic services restored in faction territories

**Player Opportunities:**
- Take on major faction missions and responsibilities
- Access advanced faction resources and facilities
- Participate in large-scale operations
- Influence faction politics and development

### Month 4+: Long-term Survival (Days 91+)
**Ongoing:** Seasonal challenges, resource competition, political evolution

**World State:**
- Seasonal weather patterns affecting operations
- Competition for long-term resources (fuel, medicine)
- Political evolution within and between factions
- Potential for major conflicts or alliances

**Player Opportunities:**
- Leadership roles within factions
- Major base development projects
- Long-term survival community building
- Influence over post-apocalyptic society development

## DYNAMIC EVENT SYSTEM

### Daily Random Events (Roll d20)
**1-10: No significant events**
**11-15: Minor events**
- Weather change affecting travel/operations
- Small zombie group spotted in area
- Message from another survivor group
- Equipment malfunction requiring repair
- NPC personal problem requiring attention

**16-18: Moderate events**
- Faction patrol encounters
- Trading opportunity with traveling merchant
- Distress signal from unknown survivors
- Resource discovery (fuel, medical supplies, etc.)
- Zombie horde movement affecting local area

**19-20: Major events**
- Faction conflict requiring player involvement
- Large zombie horde threatening area
- Significant resource discovery or loss
- New survivor group seeking alliance
- Natural disaster or infrastructure failure

### Weekly Faction Events
**Community Faction:**
- Democratic elections or policy votes
- Community projects requiring volunteer labor
- Cultural events to maintain morale
- Refugee arrivals requiring integration
- Resource sharing agreements with other factions

**Trader Faction:**
- New trade routes opening or closing
- Merchant caravan arrivals with rare goods
- Economic negotiations with other factions
- Market price fluctuations affecting trade
- Transportation equipment maintenance projects

**Militia Faction:**
- Military operations against zombie threats
- Recruitment drives and training exercises
- Intelligence gathering missions
- Territorial patrol schedule changes
- Weapon and equipment maintenance periods

**Outcast Faction:**
- Underground network expansion projects
- Guerrilla operations against authority
- Black market deals and information trading
- Safe house network security updates
- Resistance recruitment and propaganda

### Seasonal Events
**Spring (March-May):**
- Increased zombie activity as weather improves
- Faction expansion and territory consolidation
- Planting season for food production
- Infrastructure repair after winter damage

**Summer (June-August):**
- Peak activity season for all factions
- Major military operations and territorial expansion
- Trade route optimization and merchant activity
- Construction and base improvement projects

**Autumn (September-November):**
- Harvest season and resource stockpiling
- Preparation for winter survival challenges
- Faction diplomatic negotiations
- Equipment maintenance and repair focus

**Winter (December-February):**
- Reduced activity due to weather
- Resource conservation and rationing
- Indoor projects and skill development
- Increased cooperation for survival

## WORLD CONSISTENCY RULES

### Information Tracking
**Established Facts Must Remain Consistent:**
- Population numbers for factions (within reasonable ranges)
- Major faction leaders and their personalities
- Territorial boundaries and resource control
- Significant historical events in the timeline
- Infrastructure status (what's working, what's destroyed)

**Knowledge Propagation:**
- Information spreads realistically through faction networks
- Radio communications have limited range and clarity
- Rumors may be inaccurate or deliberately misleading
- Direct observation is most reliable information source

### Consequence Persistence
**Player Actions Have Lasting Effects:**
- Faction relationships change based on player behavior
- Territory control shifts based on military actions
- Resource availability changes based on usage/discovery
- NPC attitudes reflect past interactions with player

**World Responds to Player Choices:**
- Ignored problems may worsen over time
- Successful solutions may inspire similar efforts elsewhere
- Faction policies may change in response to player influence
- Economic conditions shift based on trade relationships

### Resource Economics
**Scarcity Enforcement:**
- Limited supplies cannot be endlessly replenished
- Faction resource needs drive trading relationships
- Resource discovery has lasting economic impact
- Overconsumption leads to shortages and conflict

**Technology Degradation:**
- Complex systems fail without maintenance
- Fuel supplies diminish unless actively replenished
- Communications equipment requires power and upkeep
- Transportation systems need ongoing maintenance

This world system creates a living, breathing post-apocalyptic Dublin that evolves based on realistic consequences while providing ongoing challenges and opportunities for player engagement.
