
# YGDHRA BASE AND DEFENSE SYSTEM

## BASE ESTABLISHMENT

### Choosing a Base Location
**Residential Options:**
- **House:** Moderate space, basic utilities, familiar layout
- **Apartment Building:** Multiple rooms, height advantage, multiple entrances to secure
- **Row Houses:** Connected structure, shared walls provide some protection

**Commercial Options:**
- **Shop/Store:** Ground floor access, may have useful supplies remaining
- **Office Building:** Height advantage, multiple floors, but many windows
- **Warehouse:** Large space, few entrances, industrial utilities

**Institutional Options:**
- **School:** Multiple rooms, cafeteria, gym facilities, but large perimeter
- **Hospital:** Medical supplies, but high infection risk
- **Police/Fire Station:** Good communications equipment, vehicle bay

**Industrial Options:**
- **Factory:** Robust construction, specialized equipment
- **Garage/Workshop:** Vehicle maintenance capability, tools
- **Power Station:** Potential electricity source (if repairable)

### Base Location Assessment Factors
**Security Considerations:**
- Number and type of entrances/exits
- Window placement and vulnerability
- Structural integrity of walls/doors
- Sight lines and defensible positions
- Escape route availability

**Resource Factors:**
- Proximity to water source
- Access to food/supply locations
- Distance from high-risk zombie areas
- Faction territory boundaries
- Transportation hub access

**Utility Infrastructure:**
- Electrical system condition
- Plumbing and water access
- Heating/cooling systems
- Communication equipment potential
- Waste disposal options

## DEFENSE RATING SYSTEM (1-10 Scale)

### Defense Level Calculations
**Base Defense Level = Structural + Barriers + Detection + Personnel**

**Structural Integrity (1-4 points):**
- **1:** Weak structure (tent, damaged building)
- **2:** Standard residential construction
- **3:** Commercial/institutional building
- **4:** Industrial/military grade construction

**Barriers and Fortifications (1-3 points):**
- **1:** Basic locks, furniture barricades
- **2:** Boarded windows, reinforced doors
- **3:** Purpose-built barriers, steel reinforcement

**Detection Systems (1-2 points):**
- **1:** Basic alarm system (cans/string, bells)
- **2:** Advanced detection (motion sensors, guard posts)

**Personnel (1-1 point):**
- **1:** Trained guards on duty
- **0:** No dedicated security personnel

### Defense Level Effects
**Level 1-2 (Minimal):**
- Base provides basic shelter only
- 80% chance of zombie intrusion during attacks
- No protection against human raids
- One entrance/exit maximum security

**Level 3-4 (Basic):**
- Adequate protection against single zombies
- 60% chance of zombie intrusion during attacks
- Minimal protection against human threats
- Multiple secured entrances possible

**Level 5-6 (Good):**
- Reliable protection against small zombie groups
- 40% chance of zombie intrusion during attacks
- Moderate protection against human raids
- Good sight lines and defensive positions

**Level 7-8 (Strong):**
- Protection against moderate zombie hordes
- 20% chance of zombie intrusion during attacks
- Good protection against most human threats
- Multiple defensive layers and fallback positions

**Level 9-10 (Fortress):**
- Protection against large zombie hordes
- 5% chance of zombie intrusion during attacks
- Excellent protection against human assault
- Military-grade defensive capabilities

## BASE IMPROVEMENT PROJECTS

### Basic Fortifications (Defense +1, 1-2 days)
**Window Boarding:**
- Materials: Wood planks, nails/screws, hammer
- Time: 2-4 hours per window
- Effect: Prevents zombie entry, reduces visibility both ways
- Mechanical Skill 1 required

**Door Reinforcement:**
- Materials: Metal bars, brackets, heavy-duty locks
- Time: 1-2 hours per door
- Effect: Increases door security rating
- Mechanical Skill 1 required

**Furniture Barricades:**
- Materials: Heavy furniture, rope/wire
- Time: 30 minutes per barricade
- Effect: Slows enemy movement, creates chokepoints
- No skill required, but requires sufficient STR

### Intermediate Fortifications (Defense +2, 3-7 days)
**Perimeter Fencing:**
- Materials: Chain link, posts, wire, concrete
- Time: 1-2 days depending on perimeter size
- Effect: Creates controlled access points
- Mechanical Skill 2 required

**Guard Posts:**
- Materials: Elevated platform materials, communication equipment
- Time: 1-2 days construction
- Effect: Early warning system, defensive fire positions
- Mechanical Skill 2 required

**Reinforced Safe Room:**
- Materials: Steel plating, heavy door, ventilation
- Time: 2-3 days construction
- Effect: Secure fallback position, protects VIPs/supplies
- Mechanical Skill 3 required

### Advanced Fortifications (Defense +3, 1-2 weeks)
**Wall Construction:**
- Materials: Concrete blocks, rebar, mortar
- Time: 1-2 weeks depending on length
- Effect: Serious barrier against zombies and humans
- Mechanical Skill 3 required, heavy labor team

**Gate System:**
- Materials: Steel, hydraulics/counterweights, control mechanisms
- Time: 3-5 days construction
- Effect: Controlled vehicle access, strong defense
- Mechanical Skill 4 required

**Tower/Watchtower:**
- Materials: Steel framework, platforms, communication equipment
- Time: 1 week construction
- Effect: Long-range observation, sniper positions
- Mechanical Skill 4 required

## DETECTION AND ALARM SYSTEMS

### Basic Detection (Detection +1)
**Noise Makers:**
- Materials: Cans, string, bells
- Setup Time: 30 minutes
- Range: 20 feet detection
- Effect: Alerts to movement, one-time use per trigger

**Trip Wires:**
- Materials: Wire, stakes, attachment points
- Setup Time: 1 hour
- Range: Specific pathway
- Effect: Trips intruders, may cause injury

### Advanced Detection (Detection +2)
**Motion Sensors:**
- Materials: Electronic sensors, power source, control unit
- Setup Time: 4 hours installation
- Range: 50 feet detection cone
- Effect: Silent alarm to control center
- Requirements: Electronics skill 2, power source

**Camera System:**
- Materials: Cameras, monitors, cables, recording equipment
- Setup Time: 1 day installation
- Range: Variable based on camera placement
- Effect: Visual monitoring of approaches
- Requirements: Electronics skill 3, significant power

## RESOURCE MANAGEMENT

### Base Supply Categories
**Food Storage:**
- **Current Stock:** Days of food for current population
- **Storage Method:** Preservation effectiveness
- **Spoilage Rate:** How quickly food goes bad
- **Acquisition Rate:** How fast supplies are replenished

**Water Systems:**
- **Source:** Well, city water, rain collection, bottled
- **Purification:** Filtration and sterilization capability
- **Storage Capacity:** Total gallons available
- **Daily Consumption:** Usage rate per person

**Medical Supplies:**
- **First Aid:** Basic wound treatment supplies
- **Pharmaceuticals:** Antibiotics, pain medication, etc.
- **Equipment:** IV bags, surgical tools, diagnostic equipment
- **Quarantine Space:** Isolation for infected individuals

**Power Generation:**
- **Generator Type:** Gas, diesel, solar, manual
- **Fuel Supply:** Available fuel and consumption rate
- **Power Capacity:** What can be powered simultaneously
- **Backup Systems:** Alternative power sources

**Ammunition and Weapons:**
- **Small Arms Ammo:** Rounds by caliber type
- **Weapon Maintenance:** Cleaning supplies, spare parts
- **Weapon Storage:** Secure armory space
- **Training Ammunition:** Practice rounds for skill development

### Supply Consumption Rates
**Per Person Per Day:**
- **Food:** 3 meals (2-3 pounds of food)
- **Water:** 1 gallon drinking/cooking, 2 gallons sanitation
- **Heating Fuel:** Varies by season and insulation
- **Medical:** 0.1 units average (more if injured/sick)

**Base Operations Daily:**
- **Generator Fuel:** 2-5 gallons depending on usage
- **Vehicle Fuel:** Variable based on mission requirements
- **Ammunition:** Training/practice consumption
- **Maintenance Materials:** Ongoing repair needs

## NPC TASK ASSIGNMENTS

### Guard Duty
**Requirements:** Combat skill 2+, reliable personality
**Benefits:** +2 to base detection rating while on duty
**Risk:** Guard may be first target in attack
**Schedule:** 4-hour shifts recommended to prevent fatigue

### Scavenging Teams
**Requirements:** Stealth/Survival skills, knowledge of area
**Benefits:** Regular supply acquisition from surrounding area
**Risk:** Team may encounter dangers, not return
**Efficiency:** 2-person teams optimal balance of safety/efficiency

### Maintenance and Repair
**Requirements:** Mechanical skill 2+, appropriate tools
**Benefits:** Keeps base systems functional, improves defenses
**Risk:** May be injured by equipment or structural failures
**Projects:** Can work on base improvements during downtime

### Medical Duty
**Requirements:** Medical skill 2+, access to supplies
**Benefits:** Treats injuries, monitors health, prevents disease
**Risk:** Exposure to infection when treating bite victims
**Specialization:** Higher skill levels can perform surgery

### Communications
**Requirements:** Electronics skill, radio equipment
**Benefits:** Maintains contact with other survivors, faction coordination
**Risk:** Radio transmissions may attract hostile attention
**Intelligence:** Gathers information about external threats/opportunities

### Food Production
**Requirements:** Survival skill, appropriate space/materials
**Benefits:** Reduces dependence on scavenging for food
**Risk:** Crops may fail, attracts animals/pests
**Time:** Long-term investment, several weeks to months for results

## BASE ATTACK RESOLUTION

### Attack Types
**Zombie Swarm (Small):** 3-8 zombies, random encounter
**Zombie Horde (Large):** 20+ zombies, drawn by noise/scent
**Human Raid:** 2-6 hostile survivors seeking supplies
**Faction Assault:** Organized military action with 10+ personnel

### Defense Roll Resolution
**Base Defense Roll:** d20 + Defense Rating + Personnel Bonuses
**Attack Strength:** Varies by threat type and size
**Success:** Threat repelled with minimal damage
**Failure:** Breach occurs, combat resolution required

### Breach Consequences
**Zombie Breach:**
- Zombies enter base perimeter
- Evacuation to safe room may be required
- Risk of bite/infection to defenders
- Potential loss of supplies in overrun areas

**Human Breach:**
- Armed combat with hostile survivors
- Risk of casualties among base personnel
- Potential theft of critical supplies
- May lead to ongoing faction conflict

### Damage and Recovery
**Structural Damage:** Reduces base defense rating temporarily
**Supply Loss:** Percentage of stored resources stolen/destroyed
**Personnel Casualties:** Injured/killed defenders reduce capability
**Morale Impact:** Failed defense affects NPC loyalty and stress

## SPECIAL BASE FEATURES

### Workshop Areas
**Requirements:** Tools, workspace, power source
**Benefits:** Enables advanced crafting and repair projects
**Projects:** Weapon modification, vehicle repair, electronics work
**Skill Development:** NPCs can improve mechanical skills over time

### Communications Center
**Requirements:** Radio equipment, antenna, power, skilled operator
**Benefits:** Long-range communication, intelligence gathering
**Faction Contact:** Coordinate with allied factions
**Early Warning:** Receive alerts about threats from other survivors

### Medical Bay
**Requirements:** Medical equipment, clean space, skilled medic
**Benefits:** Advanced medical treatment, surgery capability
**Quarantine:** Isolation for infected individuals
**Research:** Study of zombie virus (if equipment available)

### Vehicle Bay
**Requirements:** Large space, tools, parts, mechanical expertise
**Benefits:** Vehicle maintenance, modification, fuel storage
**Mobility:** Enables rapid evacuation or long-range missions
**Trade:** Vehicle repair services valuable to other factions

### Greenhouse/Garden
**Requirements:** Space, seeds, water, growing materials
**Benefits:** Fresh food production, reduces scavenging needs
**Sustainability:** Long-term food security
**Medicine:** Can grow medicinal plants with knowledge

## BASE ABANDONMENT

### Emergency Evacuation
**Triggers:** Overwhelming attack, structural collapse, resource depletion
**Preparation:** Pre-planned evacuation routes and rally points
**Supply Priority:** Critical items only (weapons, medicine, food)
**Regrouping:** Predetermined safe locations for survivors to reunite

### Planned Relocation
**Reasons:** Better location found, current base compromised, seasonal movement
**Preparation Time:** 1-3 days to pack and prepare
**Transport:** Vehicle requirements for people and supplies
**Transition:** Overlap period while establishing new base

The base system creates meaningful progression while emphasizing that even strong defenses require constant vigilance and resources to maintain in the zombie apocalypse.
