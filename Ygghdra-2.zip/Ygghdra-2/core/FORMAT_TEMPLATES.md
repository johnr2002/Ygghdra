# YGDHRA FORMAT TEMPLATES

## STANDARD TURN OUTPUT

### Template Structure:
```
[STAT WINDOW - Code Block]
[SCENE DESCRIPTION - 3-6 sentences]
[CHOICE OPTIONS - Numbered list]
[INPUT PROMPT]
```

## STAT WINDOW TEMPLATE

```
═══ YGDHRA SURVIVAL STATUS ═══
Day: [X] | Time: [HH:MM] | Weather: [condition] | Location: [area]

PLAYER: [Name]
├─ Health: [X/Y HP] | Stamina: [X/Y] | Infection: [X%]
├─ Status: [wounds, conditions, modifiers]
├─ Skills: [relevant skills for situation]
└─ Inventory: [key items, weapons, supplies]

[CO-OP PLAYER 2 - if applicable]
├─ Health: [X/Y HP] | Stamina: [X/Y] | Infection: [X%]
├─ Status: [wounds, conditions, modifiers]
└─ Inventory: [key items, weapons, supplies]

COMPANIONS: [Name (HP, Loyalty %)]
BASE STATUS: [Defense Level, Supplies] [if established]
SURVIVAL STATS: Days Survived: [X] | Zombies Killed: [X]
═══════════════════════════════
```

## SCENE DESCRIPTION GUIDELINES

### Structure (3-6 sentences):
1. **Immediate situation** - What's happening now
2. **Sensory details** - What you see, hear, smell
3. **Environmental factors** - Weather, lighting, atmosphere
4. **Threats/opportunities** - Zombies, NPCs, resources
5. **Character state** - Physical/mental condition impact
6. **Atmosphere** - Dublin setting, apocalypse mood

### Example:
"The abandoned pharmacy's windows are boarded up, but you can hear shuffling inside. Rain patters against the makeshift barricades while distant sirens wail across Dublin's empty streets. Your stomach growls - you haven't eaten in six hours. Through a gap in the boards, you spot medical supplies on the shelves, but shadows move between the aisles. The infection site on your arm throbs painfully, reminding you time is running short."

## CHOICE PRESENTATION TEMPLATE

```
What do you do?

1. [Direct Action] - [brief consequence hint]
2. [Defensive Action] - [brief consequence hint]
3. [Strategic Action] - [brief consequence hint]
4. [Travel Option] - ([ETA], [Risk Level])
5. [Social Action] - [if NPCs present]
6. Custom Action - (Describe your approach)
```

### Travel Choice Format:
"[Destination] - ([X minutes/hours], [Low/Moderate/High/Extreme Risk])"

## DIALOGUE FORMATTING

### NPC Speech:
**[NPC Name]:** "Dialogue text here."
*[Action or expression]*

### Player Options:
```
How do you respond?
1. "[Diplomatic response]"
2. "[Aggressive response]"
3. "[Cautious response]"
4. [Action instead of words]
5. Custom Response
```

## COMBAT FORMATTING

### Combat Rounds:
```
═══ COMBAT ROUND X ═══
Enemies: [list with conditions]
Your Status: [HP, stamina, wounds]

[Combat description paragraph]

Combat Options:
1. Attack - [weapon/method]
2. Defend - [seek cover/brace]
3. Retreat - [escape route if available]
4. Special Action - [environmental/tactical]
5. Custom Tactic
```

### Combat Results Template

**COMBAT RESULT**: Damage rolls, outcome description, status effects, environmental changes, next actions available

**FORMAT**:
```
Combat Resolution:
[Attack details and dice rolls]
[Damage and effects description] 
[Environmental/tactical changes]
[Next available actions]
```

## VISUAL SYSTEM TEMPLATES

### Status Ribbon Template
```
Day {day} • {time} • {weather} • {location}
```

### Single Player Stat Window
```
Yygdhra — Status

[Vitals]
HP {current}/{max}   Stamina {percent}%   Infection {percent}% [{bar}] (CP {cp}/15)
Wounds: {wound_list}

[Attributes]  
STR {str}  END {end}  AGI {agi}  INT {int}  PER {per}

[Skills]
Melee {melee}  Firearms {firearms}  Medical {medical}  Stealth {stealth}  Survival {survival}  Mechanical {mechanical}

[Signals]
Noise: {noise_level}   Heat: {heat_level}   Light: {light}   Ground: {ground}

[Inventory — Key Items]
{key_items_list}
```

### Co-op Split View Template
```
Yygdhra — Status  (Co‑op)

[Player: {name1}]
[Vitals]
HP {hp}   Stamina {stamina}%   Infection {inf}% [{bar}] (CP {cp}/15)
Wounds: {wounds}

[Signals]  
Noise: {noise}   Light: {light}   Ground: {ground}
Local Senses: {senses1}

[Inventory — Key Items]
{items1}

[Player: {name2}]
[Vitals]
HP {hp}   Stamina {stamina}%   Infection {inf}% [{bar}] (CP {cp}/15)  
Wounds: {wounds}

[Signals]
Noise: {noise}   Light: {light}   Ground: {ground}
Local Senses: {senses2}

[Inventory — Key Items]
{items2}

[Team Panel]
Shared: {shared_resources}
Comms: {communication_status}
```

### Choice Template with Visual Elements
```
---
Choices

1. {action1} — {description} (ETA {time}, risk {risk_icons})

2. {action2} — {description} (ETA {time}, risk {risk_icons})

3. {action3} — {description} (ETA {time}, risk {risk_icons})

4. Custom Action
```

### Visual Skin Substitutions
**Rich Skin**:
- Risk: ⚠️ ⚠️⚠️ ⚠️⚠️⚠️
- Infection bar: [███░░░░░░░░]
- Noise levels:  ▂▃▄▅▆▇█
- Alerts: 🩸 ☣️ 🎲

**Minimal Skin**:
- Risk: (RISK) (RISK+) (DANGER)  
- Infection bar: [###.......]
- Noise levels: [--] to [++]
- Alerts: [BLEEDING] [BIOHAZ] ROLL