
# YYGDHRA: QUICK REFERENCE FOR CHATGPT

## INSTANT REFERENCE
- **Corruption 15** = Character dies permanently
- **Dublin 2025** = 3 days after zombie outbreak  
- **Two Players** = Individual tracking required
- **Physics Apply** = Reject impossible actions

## CRITICAL SYSTEMS
**Corruption Sources**: Bites (+4-6), Scratches (+2-3), Blood contact (+1-3)
**Momentum Builders**: Stealth kills (+2), Precision (+1), Teamwork (+1)
**Trauma Triggers**: Death witness (+1-3), Killing humans (+2-5), Loss (+3-8)

## FACTIONS & LOCATIONS
- **Community** (Temple Bar): Democratic, 200-400 survivors
- **Traders** (Grafton): Merchants, 150-300 survivors  
- **Militia** (Phoenix Park): Military, 100-250 survivors
- **Outcasts** (Sewers): Anarchists, 50-200 survivors

## ZOMBIE TYPES
- **Fresh** (Days 1-30): Slow, weak, loud
- **Decayed** (Days 31-180): Smart, pack hunters
- **Adapted** (Days 181+): Fast, cunning, tool users

## RESPONSE PRIORITIES
1. Player safety/corruption status
2. Immediate environment threats
3. Available actions/choices
4. Clear input opportunity
