
# BASE BUILDING AND DEFENSE

## Base Types

### Residential
- **Apartment/House**: Quick setup, moderate security, limited expansion
- **Apartment Complex**: More space, harder to secure all entrances
- **Gated Community**: Good perimeter, multiple buildings, resource intensive

### Commercial
- **Shop/Restaurant**: Central location, some supplies, vulnerable
- **Warehouse**: Large space, good for groups, industrial area risks
- **Office Building**: Defensible, high visibility, limited resources

### Institutional  
- **School**: Multiple rooms, cafeteria, vulnerable to hordes
- **Hospital**: Medical supplies, power backup, heavily contested
- **Police/Fire Station**: Excellent security, weapons, limited space

### Industrial
- **Factory**: Excellent walls, manufacturing capability, isolated
- **Power Plant**: Energy source, very dangerous to capture/hold
- **Bunker**: Ultimate security, limited space, rare find

## Fortification System

### Security Levels (0-10)
- **0-2**: Unlocked doors, broken windows - no real protection
- **3-4**: Basic barricades, some entry control
- **5-6**: Reinforced entrances, early warning systems
- **7-8**: Multiple defense layers, prepared positions
- **9-10**: Fortress-level defenses, sophisticated systems

### Fortification Options
- **Barricades**: Quick, cheap, moderate effectiveness
- **Reinforced Doors**: Time-intensive, very effective vs zombies
- **Window Security**: Bars, boards, steel shutters
- **Perimeter Fencing**: Area denial, channeling, early warning
- **Watchtowers**: Overwatch, communication, sniper positions
- **Traps**: Automated defenses, zombie elimination

## Resource Management

### Essential Resources
- **Water**: 2L per person per day minimum
- **Food**: 2000 calories per person per day
- **Power**: Lights, heating, communication, refrigeration
- **Fuel**: Generators, vehicles, heating
- **Medical**: Supplies for injuries and illness

### Storage Systems
- **Inventory Tracking**: Detailed logs of all supplies
- **Rotation System**: First in, first out for perishables
- **Security**: Locked storage, access control
- **Distribution**: Fair rationing systems

## Defense Events

### Zombie Attacks
- **Wandering Singles**: Easy to dispatch, regular occurrence
- **Small Groups (2-5)**: Manageable with decent defenses
- **Large Groups (6-15)**: Serious threat, may cause damage
- **Hordes (16+)**: Overwhelming, likely to breach defenses

### Human Threats
- **Raiders**: Armed groups seeking resources
- **Faction Conflicts**: Organized military-style attacks
- **Desperate Survivors**: Usually negotiable, sometimes violent

### Environmental Hazards
- **Fires**: Can destroy entire base if not controlled
- **Floods**: Water damage, contamination, forced evacuation
- **Structural Failure**: Age, damage, poor maintenance

## Companion Roles

### Guard Duty
- **Effectiveness**: Based on loyalty and alertness
- **Schedule**: Must rotate to prevent fatigue
- **Equipment**: Weapons, communication, warm clothing

### Maintenance
- **Repair Skills**: Mechanical, electrical, construction
- **Tool Requirements**: Proper equipment needed
- **Time Investment**: Major repairs take days

### Scavenging
- **Risk Level**: Increases with distance and time
- **Skill Requirements**: Survival, stealth, navigation
- **Return Policy**: Establish return times and protocols

### Cooking/Medical
- **Resource Efficiency**: Skilled NPCs waste less
- **Quality Impact**: Better food improves morale
- **Medical Care**: Injury treatment, sickness prevention

## Expansion and Improvement

### Infrastructure Development
- **Power Systems**: Generators, solar, wind, fuel cells
- **Water Systems**: Wells, filtration, rainwater collection
- **Communication**: Radios, internet, mesh networks
- **Transportation**: Vehicle maintenance, fuel storage

### Advanced Features
- **Workshops**: Manufacturing, weapon modification, repairs
- **Gardens**: Food production, medicinal plants
- **Laboratories**: Research, medicine production, analysis
- **Command Centers**: Coordination, intelligence, planning

## Base Abandonment

### When to Leave
- **Overwhelming threat**: Defense impossible
- **Resource depletion**: Cannot sustain population
- **Strategic relocation**: Better opportunity elsewhere
- **Structural failure**: Building uninhabitable

### Evacuation Procedures
- **Critical supplies only**: Cannot carry everything
- **Destination planning**: Where to go next
- **Destruction protocol**: Deny resources to enemies
- **Escape routes**: Multiple exits planned

## Risk vs Reward Balance

### Investment Costs
- **Time**: Weeks to months for major fortifications
- **Resources**: Significant material requirements
- **Opportunity**: Cannot scavenge while building
- **Exposure**: Construction attracts attention

### Benefits
- **Safety**: Reduced daily risk from zombies
- **Efficiency**: Central storage and coordination
- **Morale**: Sense of home and achievement
- **Growth**: Platform for expanding operations

### Ongoing Costs
- **Maintenance**: Regular repairs and upkeep
- **Defense**: Guards and ammunition
- **Supplies**: Feeding and equipping occupants
- **Attention**: Bases attract both zombies and humans
