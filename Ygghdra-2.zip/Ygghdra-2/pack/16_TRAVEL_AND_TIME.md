
# TRAVEL AND TIME SYSTEM

## Time Management
- **Real-time passage**: Actions consume time realistically
- **Day/night cycle**: Affects visibility, zombie behavior, temperature
- **Weather impact**: Rain, fog, cold affect movement and health
- **Seasonal progression**: Long-term environmental changes

## Travel Mechanics

### Distance and Duration
- **Within neighborhood**: 5-15 minutes walking
- **Across district**: 20-45 minutes walking
- **Cross-city**: 1-3 hours walking
- **Rural areas**: Variable, depends on terrain and roads

### Risk Assessment
- **⚠️ Low Risk**: Quiet residential areas, daylight
- **⚠️⚠️ Moderate Risk**: Commercial districts, populated areas
- **⚠️⚠️⚠️ High Risk**: Industrial zones, known zombie concentrations
- **⚠️⚠️⚠️⚠️ Extreme Risk**: City center, hospital districts

### Travel Options
- **Walking**: Silent, flexible routing, stamina dependent
- **Running**: Faster but noisy, high stamina drain
- **Vehicle**: Fastest but requires fuel, very noisy, road dependent
- **Sneaking**: Slowest but safest, requires skill

## Random Encounters
- **Zombie patrols**: 2-6 zombies wandering
- **Survivor contacts**: Trading opportunities, information
- **Environmental hazards**: Blocked roads, dangerous terrain
- **Resource discoveries**: Abandoned supplies, hidden caches

## Weather System

### Current Conditions
- **Clear**: No penalties, good visibility
- **Light Rain**: -1 to perception, damp but manageable
- **Heavy Rain**: -3 to perception, stamina drain, noise masking
- **Fog**: -4 to perception, easy to get lost
- **Storm**: Travel inadvisable, shelter required

### Seasonal Effects (Long-term)
- **Autumn**: Increasing cold, more rain, earlier darkness
- **Winter**: Severe cold, heating requirements, reduced daylight
- **Spring**: Improving conditions, but flood risks
- **Summer**: Heat exhaustion risks, better visibility

## Route Planning

### Information Provided
- **Estimated Time of Arrival (ETA)**
- **Risk Level Assessment**
- **Known Hazards or Benefits**
- **Alternative Routes When Available**

### Example Travel Menu
```
Where to go?
1) Pharmacy (Dorset St) - ETA 15 min, Risk ⚠️⚠️ - Medical supplies
2) Supermarket (Henry St) - ETA 25 min, Risk ⚠️⚠️⚠️ - Food/water
3) Safe House (Temple Bar) - ETA 20 min, Risk ⚠️ - Secure shelter
4) Custom destination
```

## Time Pressure Events
- **Bleeding**: Requires treatment within minutes
- **Infection windows**: Treatment effectiveness decreases over time
- **Supply spoilage**: Food/medicine degrades
- **NPC schedules**: Traders, contacts have limited availability

## Night vs Day
- **Daylight (06:00-18:00)**: Better visibility, easier travel, zombies more sluggish
- **Night (18:00-06:00)**: Poor visibility, dangerous travel, zombies more active
- **Dawn/Dusk**: Transitional periods, unpredictable visibility

## Stamina and Fatigue
- **Walking**: Minimal stamina drain
- **Running**: Moderate stamina drain
- **Climbing/Swimming**: High stamina drain
- **Rest required**: Extended travel requires breaks
- **Exhaustion effects**: Penalties to all actions when stamina low
