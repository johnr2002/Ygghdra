
# CO-OP MODE IMPLEMENTATION

## Setup and Flow
1. Main Menu → Co-op Game
2. Character creation for Player 1
3. Character creation for Player 2  
4. Game begins with both characters

## Visual Layout
- Dual stat windows showing each player's individual status
- Team Panel showing shared resources and communication status
- Local Senses section for each player (sensory gating)

## Sensory Gating Rules
- Each player sees only what they personally perceive
- Communication requires diegetic action (talking, radio, etc.)
- Shared information appears in Team Panel only after communication
- No telepathic knowledge sharing

## Input Handling
- Players can take turns entering commands
- Format: "John: attacks zombie. Haikal: provides cover."
- Or separate inputs with player identification
- Simultaneous actions resolved in logical order

## Combat Coordination
- Players can assist each other
- Flanking and distraction tactics possible
- One player's failure can be aided by the other
- Shared consequences for group decisions

## Resource Management
- Individual inventories tracked separately
- Shared resources managed in Team Panel
- Trade actions required to transfer items
- Group consumption affects all players

## Communication Systems
- Face-to-face: automatic within same location
- Shouting: limited range, attracts attention
- Radio: if equipment available, battery dependent
- Silent signals: limited information transfer

## Separation Handling
- If players split up: alternate scene descriptions
- Individual choice sets for separated players
- Reunion mechanics when paths converge
- Increased difficulty when alone
