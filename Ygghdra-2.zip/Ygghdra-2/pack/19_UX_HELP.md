
# USER EXPERIENCE AND HELP SYSTEM

## Interface Commands

### Basic Commands
- **Number Selection**: Type 1, 2, 3, etc. to choose from menu
- **Custom Actions**: Type descriptive text for creative solutions
- **Help Commands**: Special commands for information

### Special Commands
- **SHOW STATS**: Display full attribute and skill panel
- **SHOW INVENTORY**: Display complete inventory list
- **SHOW MAP**: Display known locations and connections
- **SHOW TIME**: Display detailed time and weather information
- **SHOW COMPANIONS**: Display detailed companion status

### Visual Toggles
- **SKIN MINIMAL**: Switch to ASCII-only visual mode
- **SKIN RICH**: Switch to full Unicode visual mode
- **EMOJI OFF/ON**: Toggle emoji display
- **HUD COMPACT/FULL**: Toggle compact HUD mode
- **ROLLS ON/OFF**: Toggle dice roll display

## Options Menu

### Difficulty Settings
- **Casual**: Reduced damage, slower infection, more resources
- **Survivor**: Standard balanced gameplay
- **Hardcore**: Increased damage, faster infection, scarce resources

### Visual Settings
- **Rich Skin**: Unicode blocks, emoji, box drawing characters
- **Minimal Skin**: ASCII-only for maximum compatibility
- **Emoji Toggle**: ON/OFF for platform compatibility
- **Compact HUD**: Hides attributes/skills until changed

### Gameplay Settings
- **Show Rolls**: Display dice roll results for transparency
- **Auto-Save**: (Future feature) Automatic state saving
- **Difficulty Lock**: Prevent changing difficulty mid-game

## Status Window Guide

### Reading the Status
```
[Vitals]
HP 36/60        - Current/Maximum Health Points
Stamina 75%     - Energy level for actions
Infection 12%   - Zombie virus progression
[███░░░░░░░░]   - Visual infection meter
(CP 2/15)       - Corruption Points (internal scale)
Wounds: Cut arm - Active injuries affecting performance

[Attributes]
STR 6  END 7  AGI 5  INT 5  PER 6  - Core physical/mental stats

[Skills]  
Melee 3  Firearms 1  Medical 2    - Learned abilities
Stealth 2  Survival 3  Mechanical 1

[Signals]
Noise: ▃        - Current noise level you're making
Heat: ▂         - Body heat signature  
Light: Dim      - Current lighting conditions
Ground: Wet     - Environmental conditions

[Inventory — Key Items]
Kitchen knife (worn)  - Currently equipped items
Bandage ×2           - Consumable supplies
Water 1L             - Resource quantities
```

### Co-op Differences
- Two player panes showing individual status
- Local Senses section for each player
- Team Panel showing shared resources
- Communication status and range

## Choice System Guide

### Standard Choices
- **Attack/Defend/Retreat**: Basic combat options
- **Travel Options**: Show ETA and risk levels
- **Interaction Choices**: NPC dialogue and social actions
- **Custom Action**: Always available for creative solutions

### Risk Indicators
- **⚠️**: Low risk, minimal danger expected
- **⚠️⚠️**: Moderate risk, injury possible
- **⚠️⚠️⚠️**: High risk, serious danger
- **⚠️⚠️⚠️⚠️**: Extreme risk, death likely

### ETA Information
- Shows expected time to complete action
- Affected by character abilities and conditions
- Weather and environment can modify times

## Infection System Guide

### Understanding Infection
- **0-20%**: Early stage, highly treatable
- **21-40%**: Symptomatic, treatment needed
- **41-60%**: Critical, NPCs will avoid you
- **61-80%**: Terminal, severe consequences
- **81-99%**: Final stage, death imminent
- **100%**: Game Over - you turn into a zombie

### Treatment Windows
- **Immediate (0-2 min)**: Basic wound care
- **Early (0-1 hour)**: First aid treatment
- **Golden Hour (0-6 hours)**: Medical intervention
- **Advanced (0-24 hours)**: Surgical/experimental

## Combat Help

### Combat Strategies
- **Attack**: Direct confrontation, highest risk/reward
- **Defend**: Reduce incoming damage, prepare counter
- **Retreat**: Escape combat, requires successful roll
- **Custom**: Creative solutions often most effective

### Environmental Factors
- **Light**: Poor visibility reduces accuracy
- **Ground**: Wet/icy surfaces affect movement
- **Noise**: Loud actions attract more enemies
- **Cover**: Use environment for protection

## Troubleshooting

### Common Issues
- **"Can't do that"**: Action impossible due to resources/physics
- **"Roll failed"**: RNG or insufficient skill for action
- **"Reality check failed"**: Action violates game world rules
- **NPC refuses**: Low loyalty or unreasonable request

### Getting Unstuck
- **Try different approach**: Multiple solutions usually exist
- **Check resources**: May need specific items/skills
- **Ask for help**: NPCs may provide hints
- **Retreat and regroup**: Not all problems need immediate solutions

## Accessibility Features

### Visual Accommodations
- **ASCII mode**: Works on any text display
- **High contrast**: Clear distinction between elements
- **No color dependence**: Information conveyed through text/symbols
- **Consistent formatting**: Predictable layout structure

### Cognitive Accommodations
- **Clear choices**: Options explicitly presented
- **Consistent commands**: Same inputs work throughout
- **Help always available**: Information accessible anytime
- **Forgiving interface**: Typos and variants accepted

## Tips for New Players

### Survival Priorities
1. **Secure water**: Most critical short-term need
2. **Find shelter**: Reduces constant danger
3. **Treat injuries**: Infection kills faster than zombies
4. **Build relationships**: NPCs provide crucial help
5. **Plan ahead**: Reactive play leads to death

### Common Mistakes
- **Fighting everything**: Combat is dangerous, avoid when possible
- **Ignoring infection**: Even small bites can kill
- **Trusting everyone**: Some NPCs will betray you
- **Hoarding resources**: Dead players can't use supplies
- **Playing alone**: Companions significantly improve survival odds

### Advanced Strategies
- **Sound management**: Noise attracts zombies
- **Resource efficiency**: Waste nothing, share intelligently
- **Information gathering**: Knowledge is survival
- **Base selection**: Location determines long-term success
- **Relationship building**: Loyalty takes time but pays off
