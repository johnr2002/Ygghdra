
# FORMAT TEMPLATES

## Status Ribbon Format
```
Day −2  •  07:42  •  Light rain  •  Dublin — Dorset St
```

## Stat Window Format (Single Player)
```
Yygdhra — Status  (Single)

[Vitals]
HP 36/60   Stamina 75%   Infection 12% [███░░░░░░░░] (CP 2/15)
Wounds: Bruised ribs

[Attributes]
STR 6  END 7  AGI 5  INT 5  PER 6

[Skills]
Melee 3  Firearms 1  Medical 2  Stealth 2  Survival 3  Mechanical 1

[Signals]
Noise: ▃   Heat: ▂   Light: Dim   Ground: Wet

[Inventory — Key Items]
Kitchen knife (worn), Bandage ×2, Water 1L, Crackers ×1, Lighter
```

## Stat Window Format (Co-op)
```
Yygdhra — Status  (Co‑op)

[Player: John]
[Vitals]
HP 38/60   Stamina 82%   Infection 0% [░░░░░░░░░░] (CP 0/15)
Wounds: —

[Signals]
Noise: ▂   Light: Overcast   Ground: Wet
Local Senses: Footsteps ahead; faint chemical smell

[Inventory — Key Items]
Crowbar, Bandage ×1, Water 0.5L

[Player: Haikal]
[Vitals]
HP 33/50   Stamina 70%   Infection 6% [█░░░░░░░░░] (CP 1/15)
Wounds: Cut forearm (light bleeding)

[Signals] 
Noise: ▃   Light: Overcast   Ground: Wet
Local Senses: Whispering to the west; glass underfoot

[Inventory — Key Items]
Kitchen knife, Gauze ×1, Painkillers ×2

[Team Panel]
Shared: Water 2.0L, Food 4 meals, Ammo 40
Comms: Shout range only (rain); no radios
```

## Scene Format
Short paragraphs (3-6 sentences max). Environmental details, immediate threats, atmosphere.

## Choices Format
```
---
Choices

1. Front entry — kick the door (ETA 2 min, risk ⚠️⚠️)
2. Alley entrance — slower, quieter (ETA 6 min, risk ⚠️)  
3. Back to flats — regroup (ETA 4 min, risk ⚠️)
4. Custom Action
```

## Visual Elements
- Rich mode: Unicode blocks, emoji, box drawing
- Minimal mode: ASCII only
- Width limit: 78 characters
- Infection bars: [███░░░░░░░░] or [###.......]
- Risk indicators: ⚠️ symbols or (RISK) text
