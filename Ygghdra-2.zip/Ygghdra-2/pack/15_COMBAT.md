
# COMBAT SYSTEM

## Core Mechanics
- Momentum-based performance (0-10 scale)
- Realistic injury consequences
- Environmental factors critical
- Group tactics encouraged

## Momentum States

### Panic (0-3): Performance severely impacted
- Accuracy penalties: -3 to all rolls
- Possible action loss on critical failures
- Tunnel vision, poor decision making

### Normal (4-6): Standard performance
- No modifiers
- Clear thinking and steady aim

### Flow (7-10): Enhanced performance  
- Accuracy bonus: +2 to relevant rolls
- Extra actions possible
- Intimidation effects on enemies

## Combat Resolution
1. **Determine Initiative**: AGI + PER vs difficulty
2. **Declare Actions**: Attack/Defend/Retreat/Custom
3. **Apply Modifiers**: Momentum, injury, equipment, environment
4. **Roll Resolution**: Skill + Attribute + dice vs target number
5. **Calculate Damage**: Weapon damage + STR modifier - enemy toughness
6. **Apply Consequences**: HP loss, injuries, infection risk

## Injury System

### Wound Categories
- **Scratch**: Minimal impact, infection risk if from zombie
- **Minor**: -1 to relevant actions, requires basic treatment
- **Serious**: -3 to actions, bleeding, needs medical attention
- **Critical**: -5 to actions, life-threatening, immediate care required

### Specific Injuries
- **Broken Bones**: Cannot use affected limb, weeks to heal
- **Bleeding**: Ongoing HP loss until treated
- **Concussion**: INT/PER penalties, confusion
- **Shock**: All actions at -2 until stabilized

## Environmental Combat Factors
- **Lighting**: Poor visibility = accuracy penalties
- **Weather**: Rain/fog reduces perception, slippery surfaces
- **Terrain**: Obstacles provide cover but limit movement
- **Noise**: Loud actions attract more enemies

## Weapon Categories

### Melee Weapons
- **Knives**: Fast, silent, low damage, precise
- **Clubs**: Moderate damage, can stun, readily available  
- **Blades**: High damage, requires skill, breaks on poor maintenance

### Firearms
- **Pistols**: Moderate damage, limited ammo, attracts attention
- **Rifles**: High damage, accurate, very loud
- **Shotguns**: Devastating close range, wide spread, limited range

## Zombie Combat Specifics
- **Head shots**: Only reliable way to stop permanently
- **Body shots**: May slow but rarely stop
- **Noise attraction**: Gunfire draws nearby zombies
- **Infection risk**: Every contact risks CP gain

## Group Combat
- **Flanking**: Coordinate for accuracy bonuses
- **Covering**: One player provides defense while other attacks
- **Rescue**: Intervene when ally is grabbed or downed
- **Communication**: Tactics require clear coordination

## Balance Principles
- **Fresh civilian vs 2 zombies**: Dangerous, likely injury
- **Trained fighter vs 2 zombies**: Challenging but winnable
- **Anyone vs horde**: Retreat or die
- **Equipment matters**: Better weapons = better survival
- **Tactics matter**: Smart play rewarded over brute force
