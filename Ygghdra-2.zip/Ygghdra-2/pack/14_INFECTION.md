
# INFECTION SYSTEM

## Dual-Scale Tracking
- **Corruption Points (CP)**: Internal scale 0-15
- **Infection Percentage**: Player-visible 0-100% (CP × 6.67%)

## Infection Sources
- **Zombie Bite**: +4 to +6 CP
- **Zombie Scratch**: +2 to +3 CP  
- **Blood Contact**: +1 to +3 CP
- **Contaminated Consumption**: +1 to +2 CP
- **Toxic Zones**: +1 to +4 CP per exposure

## Treatment Windows

### 1. Immediate (0-2 minutes)
- Field pressure, basic cleaning
- Effect: -1 CP, stops bleeding
- Requirements: Basic supplies, any skill level

### 2. Early First Aid (0-60 minutes)  
- Thorough cleaning, disinfection, bandaging
- Effect: -1 to -2 CP
- Requirements: First aid kit, Medicine skill

### 3. Golden Hour (0-6 hours)
- Antibiotics, IV fluids, clinical care
- Effect: -2 to -4 CP  
- Requirements: Medical facility, advanced supplies

### 4. Advanced Intervention (0-24 hours)
- Surgery, transfusion, experimental treatments
- Effect: -4 to -8 CP
- Requirements: Surgical facility, expert skill, rare resources

## Infection Stages

### 0-20% (0-3 CP): Infected
- Mostly asymptomatic
- Treatment highly effective

### 21-40% (4-6 CP): Deteriorating
- Fever, fatigue, reduced performance
- NPCs may notice symptoms
- Contagious via direct fluid contact

### 41-60% (7-9 CP): Critical  
- High fever, hallucinations possible
- Severe performance penalties
- NPCs will avoid or exile player

### 61-80% (10-12 CP): Terminal
- Delirium, organ failure
- Unable to perform complex actions
- Countdown to turning accelerates

### 81-99% (13-14 CP): Final Stage
- Consciousness fading
- Near-complete incapacitation
- Last chance interventions only

### 100% (15 CP): Turned
- **GAME OVER**
- Character dies and reanimates
- No resurrection or cure possible

## Momentum Interaction
- High infection (CP ≥ 6) caps momentum at 6
- Physical limitations prevent flow states
- Stamina regeneration reduced
- Combat effectiveness severely impacted

## Environmental Factors
- Cold/wet conditions worsen infection spread
- Clean environments aid treatment
- Stress and exhaustion accelerate progression
- Proper rest and nutrition slow advancement
