
# NPCs AND COMPANIONS

## Recruitment System

### Finding Companions
- **Random encounters**: Survivors in need of help
- **Faction contacts**: Members willing to join
- **Rescue missions**: Save someone who becomes loyal
- **Trading posts**: Hire mercenaries or guides

### Recruitment Factors
- **Player reputation**: Past actions affect willingness
- **Immediate need**: Desperate NPCs more likely to join
- **Resource offers**: Food, protection, medicine as incentives
- **Skill compatibility**: NPCs prefer competent leaders

## Loyalty System (0-100 Scale)

### Loyalty Ranges
- **0-20**: Hostile, likely to betray or attack
- **21-40**: Distrustful, may abandon in danger
- **41-60**: Neutral, follows orders but reluctant
- **61-80**: Loyal, reliable in most situations
- **81-100**: Devoted, will risk life for player

### Loyalty Modifiers
- **Positive Actions**:
  - +5-10: Save NPC's life
  - +3-5: Share scarce resources
  - +2-3: Successful mission leadership
  - +1-2: Fair treatment, keeping promises

- **Negative Actions**:
  - -10-15: Betray or abandon NPC
  - -5-8: Endanger NPC unnecessarily
  - -3-5: Steal from or lie to NPC
  - -1-2: Harsh treatment, broken promises

## NPC Archetypes

### The Survivor
- **Skills**: High survival, moderate combat
- **Personality**: Pragmatic, self-reliant
- **Needs**: Security, resources, independence
- **Loyalty Growth**: Through proven competence

### The Civilian  
- **Skills**: Low combat, variable professional skills
- **Personality**: Scared, dependent, grateful
- **Needs**: Protection, food, emotional support
- **Loyalty Growth**: Through consistent care

### The Fighter
- **Skills**: High combat, low social
- **Personality**: Aggressive, direct, honor-bound
- **Needs**: Leadership, clear objectives, respect
- **Loyalty Growth**: Through shared combat

### The Medic
- **Skills**: High medical, moderate social
- **Personality**: Caring, ethical, burden by losses
- **Needs**: Purpose, supplies, moral leadership
- **Loyalty Growth**: Through helping others

### The Trader
- **Skills**: High social, moderate survival
- **Personality**: Opportunistic, networked, pragmatic
- **Needs**: Profit, connections, information
- **Loyalty Growth**: Through mutual benefit

## Command System

### Order Types
- **Movement**: "Follow me", "Wait here", "Scout ahead"
- **Combat**: "Attack", "Defend", "Take cover", "Retreat"
- **Tasks**: "Watch", "Search", "Repair", "Cook"
- **Social**: "Negotiate", "Gather information", "Distract"

### Compliance Factors
- **High Loyalty**: Follows dangerous orders willingly
- **Medium Loyalty**: Hesitates on risky commands
- **Low Loyalty**: Refuses dangerous orders, may flee

## Companion Limitations

### Skill Caps
- NPCs cannot exceed certain skill levels without training
- Player always has potential for highest advancement
- Specialization over generalization for NPCs

### Resource Consumption
- Each companion needs food, water, medical care
- Equipment degrades with use
- Larger groups harder to feed and equip

### Personality Conflicts
- Some NPCs dislike each other
- Moral differences can cause tension
- Leadership challenges if player appears weak

## Training and Improvement

### Skill Development
- NPCs improve slowly through use
- Player can mentor to accelerate growth
- Personality affects learning capacity

### Equipment Training
- New weapons require familiarization time
- Complex equipment needs instruction
- Maintenance skills must be developed

## Death and Loss

### Companion Death
- Permanent - no resurrection
- Emotional impact on surviving companions
- Possible revenge motivations
- Equipment recovery decisions

### Memorial Effects
- Other NPCs remember the fallen
- Player reputation affected by losses
- Survivor guilt mechanics possible

## Co-op Integration

### Human Players as Companions
- No loyalty system between human players
- Separate resource tracking
- Coordinate through communication
- Shared decision-making responsibilities

### Mixed Groups
- Human players + NPCs
- Complex social dynamics
- Leadership questions
- Resource distribution decisions
