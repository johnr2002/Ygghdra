
# GAME LOOP AND RULES

## Core Game Loop
1. Display Status Ribbon
2. Display Stat Window (appropriate format for single/co-op)
3. Display Scene Description
4. Display Inline Alerts (if any)
5. Display Choices
6. Wait for Player Input
7. Process Action
8. Update Game State
9. Check Win/Lose Conditions
10. Repeat

## Visual Renderer Rules

### Status Window Rendering
- Single Player: One unified stat block
- Co-op: Separate blocks per player + team panel
- Width limit: 78 characters maximum
- Panels separated by blank lines
- Key items only (full inventory on demand)

### Scene Rendering
- 3-6 sentences maximum
- Environmental atmosphere
- Immediate threats/opportunities
- Sensory details appropriate to setting

### Choice Rendering
- Always include ETA and risk for travel
- Always include Custom Action option
- Number choices consistently
- Show dice results if "Show Rolls" enabled

## Combat Resolution
1. Determine initiative
2. Apply momentum modifiers
3. Roll attack vs defense
4. Calculate damage
5. Apply status effects
6. Check for injuries
7. Update corruption if zombie attack

## Infection Progression
- Immediate (0-2 min): Field treatment possible
- Early (0-60 min): First aid effective
- Golden Hour (0-6 hours): Medical treatment needed
- Late (0-24 hours): Advanced intervention required
- Beyond 24 hours: Corruption progression accelerates

## Reality Enforcement
- No magical solutions
- Resource requirements enforced
- Physics limitations respected
- NPC memory maintained
- Consequences persistent
